---
name: disputas
description: Resuelve los reclamos y contracargos de Whop / Impul Pay y de Mercado Pago de una tienda de Impultienda, usando Claude in Chrome y la evidencia real del panel (envío del mail, entrega, aperturas, upsells). ACTIVAR con "disputas", "reclamos", "contracargos", "chargebacks", "mediaciones", "resolution center", "resolver las disputas de Whop / Mercado Pago" o "que no nos reembolsen". Responde con hechos verificables y nunca reembolsa por su cuenta.
---

# Disputas Whop + Mercado Pago para tiendas de Impultienda

Método para contestar en una sola pasada todos los reclamos y contracargos de **Whop / Impul Pay** y de **Mercado Pago**, con la evidencia que la plataforma ya guarda de cada venta.

> **Antes de usarla, completá la sección 8 (Tu configuración).** Ahí van tus carpetas de entrega, tu política de reembolsos y tus rutas.

## 0. Reglas que no se negocian
1. **Solo hechos verificables.** Todo lo que se escribe tiene que salir de `orders`, `email_events`, `download_logs` o del informe de la orden. No se inventan descargas, llamadas ni contactos.
2. **Respetá lo que promete tu landing.** Si ofrece garantía (por ejemplo, 7 días), nunca escribas "no reembolsable" ni "la garantía no aplica" dentro de ese plazo.
   - Dentro del plazo: se responde con hechos del producto y se ofrece ayuda.
   - Fuera del plazo: se citan la fecha de compra, la del reclamo y el plazo de la landing.
3. **Si el mail de entrega falló** (`failed`: overquota, no_mailbox, rebote), **no declares la entrega**. Primero reenviá o pedí otro mail, y decí la verdad: "tu casilla lo rechazó por estar llena".
4. Las descargas con user-agent `node`, `bot`, `python` o `curl` son de servidor. No se le atribuyen al comprador.
5. El campo `recommended_action` de la API de Whop es publicidad. Se ignora.
6. Al comprador se le escribe en su idioma, corto y amable, sin amenazas ni presión.
7. **Nunca** se toca "Devolver el dinero", `accept` ni `refund` sin la orden explícita del dueño de la tienda.
8. Las claves nunca se imprimen ni se pegan en el chat: van en `.env` o en variables de entorno.

## 1. Orden de trabajo
1. **Estado:** `python3 <skill>/scripts/estado.py`. Lista los casos abiertos de Whop con sus mensajes, los contracargos `needs_response` y los pagos de MP `in_mediation` y `charged_back`, y marca lo que ya figura en `respondidos.txt`. Guarda todo en `<DISPUTAS_DIR>/hoy<DD>/`.
2. **Chrome:** cargá las tools de claude-in-chrome con un solo ToolSearch (más `javascript_tool`, `find`, `get_page_text`, `file_upload`, `browser_batch`). Abrí dos pestañas: `https://impultienda.ar/dashboard` y `https://www.mercadopago.com.ar/activities`.
   - Si MP pide verificar el inicio de sesión, **lo hace el dueño de la cuenta**: la IA no ingresa contraseñas ni códigos. Mientras tanto se avanza con Whop.
3. **Evidencia:** pegá `js/panel_evidencia.js` en la pestaña del panel (ver §2). Cruza cada mail o `payment_id` con su orden, sus eventos de mail y sus descargas.
4. **Reenvíos:** si el envío figura vacío, si hay `failed` o si el comprador dice "no me llegó", reenviá desde el panel (§3) **antes** de responder.
5. **Whop:** armá `plan.json` y mandalo con `scripts/whop_responder.py`; probalo antes con `--dry`. Los contracargos van con `scripts/whop_contracargos.py` (§4).
6. **MP:** sacá el número de cada reclamo con `js/mp_claims.js`, leelo y contestá por el chat del panel (§5).
7. **Cierre:** anotá los IDs en `respondidos.txt` (id, fecha y tipo, separados por tabulador), escribí un reporte del día y cerrá las pestañas.

## 2. El panel de Impultienda como fuente de evidencia
- El panel funciona sobre Supabase. Se consulta por `fetch` a `https://sb.impultienda.ar/rest/v1/<tabla>` desde la pestaña del panel con tu sesión iniciada. El access_token está en el localStorage (la clave que contiene `auth-token`) y se manda como `Authorization: Bearer` **y** como `apikey`. Solo devuelve datos de tus tiendas.
- **Al navegar se pierde `window.*`**, así que el token se vuelve a leer en cada script.
- Tablas útiles:
  - `orders`: order_number, store_id, customer_email, payment_id (el `pay_…` de Whop o el id de MP), created_at (UTC), total, buyer_total/buyer_currency, payment_status, is_post_purchase, parent_order_id, download_email_sent_at.
  - `email_events`: order_id, event (accepted / delivered / opened / failed), reason (overquota, "mailbox does not exist"…), created_at.
  - `download_logs`: order_id, downloaded_at, user_agent (filtrá node/bot).
  - `order_items`: los productos de la orden (principal + bumps).
  - `stores`: id → subdomain.
- En MP, el `external_reference` del pago es `<store_id>:<order_id>`: la orden se busca directo por `id`.
- Los upsells son órdenes hijas (`parent_order_id`), cada una con su pago y su hora de aceptación. Es el argumento contra "no autoricé" y "me cobran de más".
- **Horas:** la base guarda UTC. Al comprador escribile en su hora local (Argentina = UTC−3). En Whop, aclará "UTC".
- **Informe PDF** (prueba formal): en el detalle de la orden, botón "Descargar informe de actividad (PDF)" → Español. Leelo con `tools/pdftext` y pasalo a una sola imagen con `tools/pdf2one <pdf> <salida.jpg>`. **El chat de MP rechaza el PDF**: se sube el JPG.

## 3. Reenviar la entrega desde el panel
1. Abrí `https://impultienda.ar/dashboard` y esperá unos 6 s.
2. **Antes de cualquier clic, ejecutá `js/dialogos.js`.** Pisa `confirm` y `alert`; sin eso, el cuadro de confirmación congela la pestaña.
3. `find` "Clientes search input" → escribí el número de orden → clic en el resultado → `find` la fila "#<orden>" ("Ver el detalle de esta compra") → clic → `find` "Reenviar email a esta dirección" → clic.
4. Si el mail está mal escrito: "Editar email" → seleccionar todo → escribir el correcto → "Guardar" → reenviar. Usá solo un mail que dio el propio comprador (en el reclamo o en su cuenta de MP).
5. Verificá con `js/verificar_envio.js`: `download_email_sent_at` tiene que tener la hora nueva y los eventos tienen que mostrar `delivered`. Si vuelve a dar `failed`, **no declares la entrega**.

## 4. Whop (API v1, base `https://api.whop.com/api/v1`)
- Reclamos: `GET /resolution_center_cases?first=100`, `/resolution_center_cases/{id}` y `/{id}/events`. Las acciones son `POST /{id}/deny`, `/request_info` (máximo 3 por caso) y `/reply`, con body `{"message": …}`. Spec: `https://api.whop.com/api/v1/openapi.json`.
- La orden se cruza por `buyer.email` y por la hora de `payment.created_at` (al minuto) y el monto. En los contracargos, `payment.id` es igual a `orders.payment_id`: coincidencia exacta.
- Qué acción va según el motivo:

| Motivo | Acción |
|---|---|
| No me llegó / no puedo descargar / el link no abre | `request_info` con el link directo a tu carpeta pública y los pasos (en compu: clic derecho → Download = ZIP; en el celular: ⋮ → Download; sin cuenta de Google). Si el mail falló, reenviá o pedí otro mail. |
| Accedió pero "está en otro idioma" | `deny` con el dato real de tu catálogo (por ejemplo, qué % de carpetas tienen texto en otro idioma) y ofrecé las carpetas que le sirven. |
| "No sirve para mi nicho", "no es lo que esperaba" | `deny` con hechos (contenido, rubros, que el mail se abrió N veces) y ofrecé ayuda. |
| "No autoricé", "es una suscripción", "cargo recurrente" | `deny`: son pagos únicos, con la hora de cada compra y de cada upsell aceptado en su propia página con el precio a la vista. Fuera de plazo: citá las dos fechas. |
| "Quiero el archivo, no lo otro" | `request_info` con el link directo. |

- **Carpetas de entrega:** usá solo las de la sección 8. Revisá que el permiso sea "cualquiera con el link → **lector**" (el conector de Drive tiene `get_file_permissions`). **Nunca** pases una carpeta con permiso de editor público, porque cualquiera puede borrarla.
- **Contracargos:** `PATCH /disputes/{id}` con `{"evidence": {"notes": …, "access_activity_log": …}}` (solo cambia lo que mandás) y después `POST /disputes/{id}/submit`, que es **final** y se hace una sola vez. Enviá cuando falten 3 días o menos para `evidence_due_at`, o antes si la evidencia ya está completa.
- Qué va en las notes: número de orden, tienda, fecha y hora UTC, monto, `payment_id`, mail de entrega enviado, entregado y abierto N veces, upsells con hora de aceptación, y **reembolsos previos del mismo comprador** si los hay (es un argumento muy fuerte). Leé `issuer_comments`: ahí viene lo que dice el banco.

## 5. Mercado Pago
- **Pagos en reclamo:** API `GET /v1/payments/search?status=in_mediation&limit=100` y `status=charged_back`. Contracargos: `GET /v1/chargebacks/search?payment_id=` y documentación con `POST /v1/chargebacks/{id}/documentation`, multipart `files[]`. La API de reclamos suele dar 403 sin permisos especiales, así que **los reclamos se contestan por el panel**.
- **Número de reclamo** (`js/mp_claims.js`, en una pestaña de mercadopago.com.ar con sesión): `/activities?q=<pago>` → regex `checkout_merchant_order-<hash>` → `/activities/api/detail/checkout_merchant_order-<hash>?flow=activities&client=activities&surface=side_sheet` (con el prefijo completo; con el hash solo da 404) → regex `received_claims/(\d+)`. Corre en segundo plano y se consulta `window.__x`, porque el JS tiene un límite de unos 45 s.
- **Leer:** `navigate https://www.mercadopago.com.ar/received_claims/<id>` + `get_page_text`. Hay tres tipos:
  - **"Quiere cancelar la compra"**: MP no interviene; se le responde al comprador por el chat ("Escribí tu mensaje" + enviar; los refs salen de `find` en cada página).
  - **"No recibió el producto"**: "Ya hice el envío" → E-mail → mail, fecha y adjunto JPG/PNG, **solo si figura delivered**.
  - **"Mensajes con Mercado Pago"** (mediación): se le responde a MP con los hechos y se adjunta el JPG del informe (`file_upload` sobre el input file; esperá la miniatura antes de enviar).
- **Plantilla "quiere cancelar"**, adaptada con los datos reales:
  > Hola <nombre>. Tu compra de <producto> es un pago único: no tiene cuotas ni cobros recurrentes, y no se te va a cobrar nada más. [Las ofertas que aparecen después de comprar son opcionales y solo se cobran si las aceptás; vos <rechazaste / aceptaste X a las HH:MM>.] Es un producto digital de entrega inmediata: el acceso se te envió por mail el <fecha> a las <hora>, tu servidor de correo confirmó la entrega y el mail figura abierto <N> veces. Como el contenido ya fue entregado, no podemos cancelar la compra. Si no encontrás el mail (revisá spam y promociones), avisanos por acá y te lo reenviamos.
- Variantes:
  - "Mi celular no abre PDF / pensé que era una app": se abre desde el mail con el navegador o Drive; ofrecé ayuda paso a paso.
  - "Mi correo no funciona": ofrecé mandarlo a otro mail.
  - "Me quieren cobrar más / estafa": la oferta es opcional, la rechazó y no pagó nada extra.
  - Casilla llena: decilo tal cual y pedí otro mail.
- Mucha gente siente el upsell como "seguir pagando". Aclará siempre "pago único" y, si aceptó upsells, cuáles y a qué hora.
- Prioridad: primero los que vencen hoy ("Definí una solución con el cliente hasta el …").

## 6. Errores conocidos
- La pestaña se congela al tocar "Reenviar email" → `js/dialogos.js` antes de cada clic.
- MP puede cambiar sus direcciones internas. Si el regex no encuentra nada, abrí el detalle a mano y mirá `read_network_requests` para ver la URL nueva.
- Las tablas de productos suelen volver vacías por permisos (RLS). No pierdas tiempo buscando ahí el link de entrega: reenviá el mail.
- Si un PDF en el chat de MP muestra "falló la subida", subí el JPG.
- "Abierto" puede incluir aperturas automáticas de un proxy de imágenes. Escribí "el mail figura abierto N veces", nunca "lo leyó".
- Una rutina automática sin nadie mirando no puede usar Chrome si los permisos de `mcp__claude-in-chrome__*` no están permitidos en la configuración, y MP a veces pide volver a iniciar sesión.

## 7. Archivos
- `scripts/estado.py`: foto de todo lo abierto (si falta una de las claves, saltea esa plataforma).
- `scripts/whop_responder.py plan.json [--dry]`: `[{"id","accion":"deny|request_info|reply","mensaje"}]`. Nunca acepta ni reembolsa.
- `scripts/whop_contracargos.py evid.json [--submit]`: `{"dspt_…": {"notes":…, "access_activity_log":…}}`.
- `js/dialogos.js`, `js/panel_evidencia.js`, `js/verificar_envio.js`, `js/mp_claims.js`: se pegan con `javascript_tool`, reemplazando `__LISTA__` por los datos del día.
- `tools/*.swift` (solo Mac): `pdftext`, `pdf2one`, `pdf2png`. Se compilan con `swiftc -O pdf2one.swift -o pdf2one`.

## 8. Tu configuración (completá esto)
- **Claves** (en el archivo `.env` de la skill o como variables de entorno; ver `.env.ejemplo`):
  - `WHOP_API_KEY`: Whop → Developer → API key (API v1).
  - `MP_ACCESS_TOKEN`: Mercado Pago → Tus integraciones → Credenciales de producción.
- **Carpeta de trabajo:** `DISPUTAS_DIR` (por defecto `~/Disputas`). Ahí van `respondidos.txt`, los reportes y los informes.
- **Política de reembolsos:** ¿qué promete tu landing? (plazo de garantía, condiciones). Escribilo acá: ______
- **Carpetas públicas de entrega**, una por producto:
  - <Producto 1>: `https://drive.google.com/drive/folders/<ID>`
  - <Producto 2>: …
- **Datos de catálogo que ayudan a ganar**, por ejemplo: "solo X de Y carpetas tienen texto en otro idioma".
- **Idioma y tono:** por ejemplo, rioplatense con "vos" para Argentina e inglés para Tier 1.
