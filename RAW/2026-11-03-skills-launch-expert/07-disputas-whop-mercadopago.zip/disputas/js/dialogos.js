// Pegar ANTES de tocar "Reenviar email" u otro botón del panel: evita que confirm/alert congelen la pestaña.
window.__dlg=[];window.alert=m=>window.__dlg.push('A:'+m);window.confirm=m=>{window.__dlg.push('C:'+m);return true};'ok'
