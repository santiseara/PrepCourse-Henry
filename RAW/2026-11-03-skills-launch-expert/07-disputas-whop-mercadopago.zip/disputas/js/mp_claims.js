// Pestaña mercadopago.com.ar con sesión. Reemplazá __LISTA__ por [185444649463, ...]. Corre en segundo plano:
// después consultá con  JSON.stringify(window.__x)  hasta que aparezca done:1.
const P=__LISTA__;window.__x={};(async()=>{for(const p of P){try{
const t=await (await fetch('/activities?q='+p)).text();const m=t.match(/checkout_merchant_order-([a-f0-9]+)/);if(!m){window.__x[p]='sin-hash';continue}
const d=await (await fetch('/activities/api/detail/checkout_merchant_order-'+m[1]+'?flow=activities&client=activities&surface=side_sheet')).text();
const c=[...new Set([...d.matchAll(/received_claims\/(\d+)/g)].map(x=>x[1]))];
const st=(d.match(/"title":"(Cobro en mediaci[^"]*|Reclamo[^"]*|Te iniciaron[^"]*)"/)||[])[1]||'';
window.__x[p]=(c.join(',')||'sin-reclamo')+' '+st}catch(e){window.__x[p]='err '+e.message}}window.__x.done=1})();'started'
