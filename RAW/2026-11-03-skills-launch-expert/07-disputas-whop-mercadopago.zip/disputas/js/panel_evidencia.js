// Pestaña impultienda.ar. Reemplazá __LISTA__ por [["etiqueta","mail o null","payment_id o null"], ...]
// Devuelve por orden: tienda, hora UTC, monto, si es upsell, envío, eventos de mail, descargas humanas y upsells hijos.
const k=Object.keys(localStorage).find(k=>k.includes('auth-token'));const t=JSON.parse(localStorage.getItem(k)).access_token;
const H={Authorization:'Bearer '+t,apikey:t};const B='https://sb.impultienda.ar/rest/v1/';
const J=async u=>(await fetch(B+u,{headers:H})).json();
const sm=Object.fromEntries((await J('stores?select=id,subdomain')).map(s=>[s.id,s.subdomain]));
const L=__LISTA__;const out=[];
for(const [tag,em,pay] of L){
  const f=pay?'payment_id=eq.'+pay:'customer_email=eq.'+encodeURIComponent(em);
  const os=await J('orders?select=id,order_number,store_id,created_at,total,buyer_total,buyer_currency,payment_status,is_post_purchase,download_email_sent_at&'+f+'&order=created_at.asc');
  for(const o of os.filter(o=>o.payment_status!=='rejected')){
    const ev=await J('email_events?select=event,reason&order_id=eq.'+o.id);const e={};
    for(const x of ev){e[x.event]=(e[x.event]||0)+1;if(x.event==='failed')e.motivo=(x.reason||'').slice(0,40)}
    const dl=(await J('download_logs?select=user_agent&order_id=eq.'+o.id)).filter(d=>!/node|bot|python|curl/i.test(d.user_agent||'')).length;
    const kids=(await J('orders?select=order_number,created_at,total&payment_status=eq.approved&parent_order_id=eq.'+o.id)).map(c=>'#'+c.order_number+'@'+c.created_at.slice(11,16)+' $'+c.total);
    out.push(`${tag} #${o.order_number} ${sm[o.store_id]} ${o.created_at.slice(5,16)}Z ${o.buyer_total||o.total}${o.buyer_currency||''} ${o.payment_status} pp=${o.is_post_purchase} envio=${(o.download_email_sent_at||'NO').slice(5,16)} ${JSON.stringify(e)} dl=${dl} ups=${kids.join(',')}`)}}
window.__out=out;out.join('\n')   // si se trunca: window.__out.slice(10).join('\n')
