// Pestaña impultienda.ar. Reemplazá __LISTA__ por [2170672, 2035018, ...] (números de orden). Muestra el último envío y los eventos de hoy.
const k=Object.keys(localStorage).find(k=>k.includes('auth-token'));const t=JSON.parse(localStorage.getItem(k)).access_token;const H={Authorization:'Bearer '+t,apikey:t};
const N=__LISTA__;const hoy=new Date().toISOString().slice(0,10);
const os=await (await fetch('https://sb.impultienda.ar/rest/v1/orders?select=id,order_number,download_email_sent_at&order_number=in.('+N.join(',')+')',{headers:H})).json();
const ev=await (await fetch('https://sb.impultienda.ar/rest/v1/email_events?select=order_id,event,reason&created_at=gte.'+hoy+'&order_id=in.('+os.map(o=>o.id).join(',')+')&order=created_at.asc',{headers:H})).json();
os.map(o=>o.order_number+' envio='+(o.download_email_sent_at||'').slice(5,16)+'Z '+ev.filter(e=>e.order_id===o.id).map(e=>e.event+(e.reason?'('+e.reason.slice(0,30)+')':'')).join(',')).join('\n')
