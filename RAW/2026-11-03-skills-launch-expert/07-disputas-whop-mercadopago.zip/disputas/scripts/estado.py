#!/usr/bin/env python3
"""Foto de disputas abiertas: Whop (reclamos + contracargos) y Mercado Pago (mediación + contracargos).
Uso: python3 estado.py   → imprime resumen y guarda JSON en <DISPUTAS_DIR>/hoy<DD>/"""
import json, os, datetime, urllib.request
from pathlib import Path

def cargar_env():
    """Lee WHOP_API_KEY y MP_ACCESS_TOKEN de las variables de entorno o del archivo .env de la skill."""
    f = Path(__file__).resolve().parent.parent / ".env"
    if f.exists():
        for l in f.read_text().splitlines():
            if "=" in l and not l.strip().startswith("#"):
                k, v = l.split("=", 1); os.environ.setdefault(k.replace("export ", "").strip(), v.strip().strip('"\''))
cargar_env()
OUT = Path(os.environ.get("DISPUTAS_DIR", Path.home() / "Disputas")).expanduser() / f"hoy{datetime.date.today():%d}"; OUT.mkdir(parents=True, exist_ok=True)
RESP = Path(os.environ.get("DISPUTAS_DIR", Path.home() / "Disputas")).expanduser() / "respondidos.txt"
resp = {l.split("\t")[0] for l in RESP.read_text().splitlines() if l.strip()} if RESP.exists() else set()

def get(base, path, tok):
    r = urllib.request.Request(base + path, headers={"Authorization": "Bearer " + tok})
    return json.load(urllib.request.urlopen(r, timeout=40))

# --- Whop (se saltea si no hay WHOP_API_KEY)
def whop():
    W = lambda p: get("https://api.whop.com/api/v1", p, os.environ["WHOP_API_KEY"])
    casos = []
    for x in W("/resolution_center_cases?first=100")["data"]:
        if x["status"] not in ("awaiting_merchant", "awaiting_customer"): continue
        d = W("/resolution_center_cases/" + x["id"])
        try: ev = W(f"/resolution_center_cases/{x['id']}/events").get("data", [])
        except Exception: ev = []
        d.pop("recommended_action", None); casos.append({"case": d, "events": ev})
    json.dump(casos, open(OUT / "whop_casos.json", "w"), indent=1)
    print(f"== WHOP reclamos abiertos: {len(casos)}")
    for o in sorted(casos, key=lambda o: o["case"].get("response_due_at") or ""):
        d = o["case"]; li = (d.get("line_items") or [{}])[0]
        print(f"{d['id']} {d['status']} {d.get('reason')} {d.get('amount')}{d.get('currency')} pago {d['payment']['created_at'][:16]} vence {str(d.get('response_due_at'))[:10]} | {li.get('product_title','')[:45]} | {d['buyer']['email']}")
        for e in o["events"]:
            print(f"    - {e.get('created_at','')[:16]} {e.get('action') or e.get('type')}: {str(e.get('message') or '')[:220]}")
    disp = []
    for x in W("/disputes?first=100")["data"]:
        if x.get("status") in ("needs_response", "warning_needs_response"):
            d = W("/disputes/" + x["id"]); d.pop("recommended_action", None); disp.append(d)
    json.dump(disp, open(OUT / "whop_contracargos.json", "w"), indent=1)
    print(f"\n== WHOP contracargos needs_response: {len(disp)}")
    for d in sorted(disp, key=lambda d: d.get("evidence_due_at") or ""):
        li = (d.get("line_items") or [{}])[0]
        print(f"{d['id']} {d['amount']}{d['currency']} {d['reason']} vence {d['evidence_due_at'][:10]} | {d['payment']['id']} {d['payment']['created_at'][:16]} | {li.get('product_title','')[:40]} | {(d.get('buyer') or {}).get('email')}")
        for c in d.get("issuer_comments") or []: print("    banco:", c.get("text", "")[:300])

if os.environ.get("WHOP_API_KEY"): whop()
else: print("(sin WHOP_API_KEY: salteo Whop)")

# --- Mercado Pago (se saltea si no hay MP_ACCESS_TOKEN)
if not os.environ.get("MP_ACCESS_TOKEN"):
    print("\n(sin MP_ACCESS_TOKEN: salteo Mercado Pago)"); print(f"\nGuardado en {OUT}"); raise SystemExit
M = lambda p: get("https://api.mercadopago.com", p, os.environ["MP_ACCESS_TOKEN"])
med = M("/v1/payments/search?status=in_mediation&limit=100&sort=date_created&criteria=desc")["results"]
mp = [{"pago": p["id"], "fecha": p["date_created"][:16], "monto": p["transaction_amount"],
       "email": (p.get("payer") or {}).get("email"), "order_id": (p.get("external_reference") or ":").split(":")[-1],
       "desc": p.get("description", "")[:50]} for p in med]
json.dump(mp, open(OUT / "mp_mediacion.json", "w"), indent=1)
print(f"\n== MP en mediación: {len(mp)} (el claim id sale con js/mp_claims.js; respondidos.txt guarda claim ids)")
for p in mp: print(p["pago"], p["fecha"], p["monto"], (p["email"] or "")[:4] + "***", p["order_id"], p["desc"])
print("\n== MP contracargos")
for p in M("/v1/payments/search?status=charged_back&limit=50&sort=date_created&criteria=desc")["results"]:
    for c in M(f"/v1/chargebacks/search?payment_id={p['id']}").get("results") or []:
        print(p["id"], p["transaction_amount"], c.get("id"), c.get("documentation_status"), "cobertura", c.get("coverage_applied"),
              "vence", str(c.get("date_documentation_deadline"))[:10], "YA" if str(c.get("id")) in resp else "NUEVO")
print(f"\nGuardado en {OUT}")
