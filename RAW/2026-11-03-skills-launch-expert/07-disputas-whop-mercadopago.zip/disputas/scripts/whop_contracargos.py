#!/usr/bin/env python3
"""Carga evidencia en contracargos de Whop y opcionalmente los envía (submit es FINAL).
Uso: whop_contracargos.py evid.json [--submit]
evid.json = {"dspt_…": {"notes": "…", "access_activity_log": "…", "product_description": "…"}}"""
import json, os, sys, urllib.request
from pathlib import Path
def cargar_env():
    """Lee WHOP_API_KEY y MP_ACCESS_TOKEN de las variables de entorno o del archivo .env de la skill."""
    f = Path(__file__).resolve().parent.parent / ".env"
    if f.exists():
        for l in f.read_text().splitlines():
            if "=" in l and not l.strip().startswith("#"):
                k, v = l.split("=", 1); os.environ.setdefault(k.replace("export ", "").strip(), v.strip().strip('"\''))
cargar_env()
K = os.environ["WHOP_API_KEY"]
def call(m, p, b=None):
    r = urllib.request.Request("https://api.whop.com/api/v1" + p, data=json.dumps(b).encode() if b is not None else None,
        headers={"Authorization": "Bearer " + K, "Content-Type": "application/json"}, method=m)
    try: return json.load(urllib.request.urlopen(r, timeout=40))
    except urllib.error.HTTPError as e: return {"error": e.read().decode()[:300]}
for i, ev in json.load(open(sys.argv[1])).items():
    r = call("PATCH", "/disputes/" + i, {"evidence": ev})
    print(i, "PATCH ->", r.get("status"), r.get("error", ""))
    if "--submit" in sys.argv and not r.get("error"):
        s = call("POST", f"/disputes/{i}/submit", {})
        print(i, "SUBMIT ->", s.get("status"), s.get("evidence_submitted_at"), s.get("error", ""))
