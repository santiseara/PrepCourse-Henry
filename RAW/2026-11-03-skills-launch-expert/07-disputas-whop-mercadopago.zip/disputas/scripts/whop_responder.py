#!/usr/bin/env python3
"""Responde reclamos del Resolution Center de Whop. Uso: whop_responder.py plan.json [--dry]
plan.json = [{"id": "reso_…", "accion": "deny|request_info|reply", "mensaje": "…"}]. Nunca accept/refund."""
import json, os, sys, urllib.request
from pathlib import Path
def cargar_env():
    """Lee WHOP_API_KEY y MP_ACCESS_TOKEN de las variables de entorno o del archivo .env de la skill."""
    f = Path(__file__).resolve().parent.parent / ".env"
    if f.exists():
        for l in f.read_text().splitlines():
            if "=" in l and not l.strip().startswith("#"):
                k, v = l.split("=", 1); os.environ.setdefault(k.replace("export ", "").strip(), v.strip().strip('"\''))
cargar_env()
KEY = os.environ["WHOP_API_KEY"]; dry = "--dry" in sys.argv
for p in json.load(open(sys.argv[1])):
    assert p["accion"] in ("deny", "request_info", "reply"), p
    if dry: print(p["id"], p["accion"], len(p["mensaje"]), "chars"); continue
    req = urllib.request.Request(f"https://api.whop.com/api/v1/resolution_center_cases/{p['id']}/{p['accion']}",
        data=json.dumps({"message": p["mensaje"]}).encode(),
        headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"}, method="POST")
    try: r = json.load(urllib.request.urlopen(req, timeout=30))
    except urllib.error.HTTPError as e: r = {"error": e.read().decode()[:300]}
    print(p["id"], p["accion"], "->", r.get("status"), r.get("outcome"), r.get("error", ""))
