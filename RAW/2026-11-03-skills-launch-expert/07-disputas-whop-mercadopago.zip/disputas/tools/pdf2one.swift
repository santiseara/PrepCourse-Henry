import PDFKit
import AppKit
// Uso: pdf2one archivo.pdf salida.png -> todas las páginas apiladas en una sola imagen
let doc = PDFDocument(url: URL(fileURLWithPath: CommandLine.arguments[1]))!
let scale: CGFloat = 1.5
let box = doc.page(at: 0)!.bounds(for: .mediaBox)
let w = box.width * scale, h = box.height * scale
let img = NSImage(size: NSSize(width: w, height: h * CGFloat(doc.pageCount)))
img.lockFocus()
NSColor.white.set(); NSRect(origin: .zero, size: img.size).fill()
let ctx = NSGraphicsContext.current!.cgContext
for i in 0..<doc.pageCount {
    ctx.saveGState()
    ctx.translateBy(x: 0, y: h * CGFloat(doc.pageCount - 1 - i))
    ctx.scaleBy(x: scale, y: scale)
    doc.page(at: i)!.draw(with: .mediaBox, to: ctx)
    ctx.restoreGState()
}
img.unlockFocus()
let rep = NSBitmapImageRep(data: img.tiffRepresentation!)!
try! rep.representation(using: .jpeg, properties: [.compressionFactor: 0.85])!.write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
