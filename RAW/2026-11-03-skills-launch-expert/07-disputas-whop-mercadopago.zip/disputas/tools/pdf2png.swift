import PDFKit
import AppKit
// Uso: pdf2png archivo.pdf  -> archivo-p1.png, archivo-p2.png ...
let path = CommandLine.arguments[1]
guard let doc = PDFDocument(url: URL(fileURLWithPath: path)) else { print("no pdf"); exit(1) }
for i in 0..<doc.pageCount {
    let page = doc.page(at: i)!
    let box = page.bounds(for: .mediaBox)
    let scale: CGFloat = 2
    let img = NSImage(size: NSSize(width: box.width * scale, height: box.height * scale))
    img.lockFocus()
    NSColor.white.set(); NSRect(origin: .zero, size: img.size).fill()
    let ctx = NSGraphicsContext.current!.cgContext
    ctx.scaleBy(x: scale, y: scale)
    page.draw(with: .mediaBox, to: ctx)
    img.unlockFocus()
    let rep = NSBitmapImageRep(data: img.tiffRepresentation!)!
    let out = path.replacingOccurrences(of: ".pdf", with: "-p\(i+1).png")
    try! rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: out))
    print(out)
}
