import PDFKit
// Uso: pdftext archivo.pdf  -> imprime el texto del PDF
let doc = PDFDocument(url: URL(fileURLWithPath: CommandLine.arguments[1]))!
print(doc.string ?? "")
