"""Control de cada clip + bordes exactos. Alineación forzada MMS contra el guion (precisión 20 ms) → dónde empieza y termina cada palabra;
se descartan los rellenos y se transcribe el tramo AISLADO con Whisper medium para comparar contra el guion.
Uso: python3 <skill>/scripts/alinear.py [clave ...]  → words.json. Imprime «MAL» en los que hay que regenerar.
Nunca uses Whisper para los bordes: pone la 1ª palabra en 0,00 s y deja sílabas sueltas en los empalmes."""
import json, os, sys, re, subprocess, difflib, warnings; warnings.filterwarnings("ignore")
import numpy as np, torch, torchaudio, soundfile as sf
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import cfg, ruta, FF, relleno
from norm_es import n
from faster_whisper import WhisperModel

B = torchaudio.pipelines.MMS_FA; model = B.get_model(with_star=False).eval(); DIC = B.get_dict(star=None); aligner = B.get_aligner()
WM = WhisperModel("medium", compute_type="int8"); C = cfg(); LANG = C.get("idioma", "es")


def load(p, sr=16000):
    return np.frombuffer(subprocess.run([FF, "-v", "error", "-i", p, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"], capture_output=True).stdout, np.float32).copy()


def tok(w): return "".join(re.sub(r"[^a-z']", "", p.replace("ñ", "n")) for p in n(w))
def cmp(a, b): return difflib.SequenceMatcher(None, "".join(map(tok, a.split())), "".join(map(tok, b.split()))).ratio()


OF = ruta("words.json"); OUT = json.load(open(OF)) if os.path.exists(OF) else {}
for c in C["clips"]:
    k = c["k"]
    if not c.get("personaje") or (sys.argv[1:] and k not in sys.argv[1:]): continue
    clip = ruta("clips", k + ".mp4")
    if not os.path.exists(clip): print("FALTA", k); continue
    t = c["texto"]; lead, tail = relleno(t); ws = [w for w in lead.split() + t.split() + tail.split() if tok(w)]
    nl, nt = len([w for w in lead.split() if tok(w)]), len([w for w in tail.split() if tok(w)])
    au = load(clip); dur = len(au) / 16000
    with torch.inference_mode():
        em, _ = model(torch.from_numpy(au)[None]); em = torch.log_softmax(em, -1)
        sp = aligner(em[0], [[DIC[ch] for ch in tok(w)] for w in ws])
    fps = em.shape[1] / dur
    A = [(s[0].start / fps, s[-1].end / fps, w, float(np.mean([x.score for x in s]))) for w, s in zip(ws, sp)]
    body = A[nl:len(A) - nt]
    a = max(A[nl - 1][1] + 0.02, body[0][0] - 0.10); b = min(dur - 0.02, body[-1][1] + 0.16, A[len(A) - nt][0] - 0.03)
    y = load(clip, 48000)[int(a * 48000):int(b * 48000)]; sf.write(ruta("voz", k + ".wav"), y, 48000)
    segs, _ = WM.transcribe(ruta("voz", k + ".wav"), language=LANG, temperature=0, vad_filter=False); oido = " ".join(x.text.strip() for x in segs)
    r = cmp(t, oido)
    OUT[k] = {"a": a, "b": b, "dur": dur, "words": [[s, e, w] for s, e, w, _ in body], "oido": oido, "r": r}
    print(("MAL " if r < 0.9 else "ok  ") + f"{k:5} {r:.2f}  [{a:.2f}-{b:.2f} de {dur:.2f}s]  oído: {oido}", flush=True)
json.dump(OUT, open(OF, "w"), ensure_ascii=False, indent=1)
print("\nOjo: Whisper a veces escribe sin tilde el voseo. Si en TODOS los clips escribe bien «tenés/sentís» y en uno oye «toca/completa», es wan diciendo la forma de tú: reescribí la frase («tenés que tocar…»).")
