"""Tomas mudas (fotos del testimonio que se mueven) con Hailuo 2.3 por ApiMart, 6 s, ~US$0,26 cada una.
Uso: python3 <skill>/scripts/animar.py [salida.mp4 ...]
Si el filtro rechaza ("did not pass content safety review", no cobra): sacá del prompt las partes del cuerpo y describí solo el movimiento."""
import sys, os, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import cfg, ruta, video, subir

want = sys.argv[1:]


def go(a):
    out = ruta("clips", a["out"])
    if os.path.exists(out): return
    try:
        video({"model": "MiniMax-Hailuo-2.3", "prompt": "Vertical smartphone video, realistic, natural movement, no slow motion, no morphing, no text. One continuous shot, subtle handheld movement. " + a["prompt"],
               "duration": 6, "resolution": "768p", "first_frame_image": subir(f"img/{a['foto']}")}, out); print("OK", a["out"], flush=True)
    except BaseException as e: print("ERR", a["out"], str(e)[:300], flush=True)


ts = [threading.Thread(target=go, args=(a,)) for a in cfg().get("animaciones", []) if not want or a["out"] in want]
[t.start() for t in ts]; [t.join() for t in ts]
