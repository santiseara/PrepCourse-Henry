"""Clips con avatar que habla: wan2.7-r2v (ApiMart) con UNA voz de referencia fija por personaje.
Uso: python3 <skill>/scripts/clips.py [clave ...]   → clips/<clave>.mp4  (solo genera los que faltan; para rehacer uno, movelo a clips/viejos/)
Costo de referencia: ~US$0,06 por segundo (un clip de 7 s ≈ US$0,42). Regla: 1 clip de prueba y OK antes del lote."""
import sys, os, re, json, time
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import cfg, ruta, video, subir, relleno, duracion, saldo

C = cfg(); ACENTO = C["acento"]; PERS = C["personajes"]


def acentos(t):
    """voseo: le recuerda a wan qué sílaba lleva el acento (tenés, sentís, escuchame)."""
    ws = [w for w in re.findall(r"[a-záéíóúñ]+", t.lower()) if w[-1] in "áéí" or re.search(r"[áéí](me|te|la|lo|le|nos)$", w)]
    return (" Stress the accented syllable exactly as written in " + ", ".join(dict.fromkeys(ws)) + ".") if ws and C.get("voseo", True) else ""


def prompt(c, tt):
    p = PERS[c["personaje"]]; quien = p.get("genero", "woman")
    fondo = f" In the background {c['fondo']}. Their body shape, size and clothes stay exactly as in the first frame for the whole video." if c.get("fondo") else ""
    return f"""One single continuous shot with no cuts, no jump zooms and no camera angle changes. Same framing, same people and same background as the first frame. Handheld vertical selfie video recorded on a phone front camera. {p['descripcion']} talks to the camera with natural expressive facial movements; {c.get('gesto', 'gestures naturally with the free hand')}. Slight natural handheld shake.{fondo}
The {quien} speaks with exactly the same voice and accent as the reference voice sample, in {ACENTO}, like {p.get('tono', 'someone talking to their followers on Instagram')}.{acentos(tt)} Exactly these words and nothing else, at a lively natural pace, finishing the last word clearly and then staying silent for a moment before the video ends:
"{tt.replace('"', '')}"
No music, no subtitles, no text on screen."""


def go(c):
    out = ruta("clips", c["k"] + ".mp4")
    if os.path.exists(out): return
    lead, tail = relleno(c["texto"]); tt = f"{lead} {c['texto']} {tail}"; p = PERS[c["personaje"]]
    for n in range(4):                                    # si falla 4 veces seguidas: cambiá el gesto o la frase, no insistas igual
        try:
            foto = subir(f"img/{c['foto']}"); voz = subir(f"voces/{p['voz']}")
            video({"model": "wan2.7-r2v", "prompt": prompt(c, tt),
                   "image_with_roles": [{"url": foto, "role": "reference_image", "reference_voice": voz}, {"url": foto, "role": "first_frame"}],
                   "resolution": "720P", "duration": duracion(c["texto"]), "size": "9:16", "prompt_extend": False}, out)
            json.dump({"t": tt}, open(out[:-4] + ".json", "w"), ensure_ascii=False); print("OK", c["k"], flush=True); return
        except SystemExit: raise
        except Exception as x: print("ERR", c["k"], n, str(x)[:250], flush=True); time.sleep(20)


if __name__ == "__main__":
    ks = sys.argv[1:]; js = [c for c in C["clips"] if c.get("personaje") and (not ks or c["k"] in ks)]
    with ThreadPoolExecutor(int(os.environ.get("HILOS", 8))) as ex: list(ex.map(go, js))
    print("FIN · saldo ApiMart", saldo(), flush=True)
