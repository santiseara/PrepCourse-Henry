"""Piezas comunes: configuración del proyecto, cliente de ApiMart, subida de archivos, ffmpeg y relleno de las líneas.
Todos los scripts se corren DESDE la carpeta del proyecto (la que tiene proyecto.json)."""
import json, os, re, math, shutil, subprocess, time, threading

PROY = os.getcwd()
CFG_PATH = os.path.join(PROY, "proyecto.json")
FF = shutil.which("ffmpeg") or os.path.expanduser("~/.local/bin/ffmpeg")
FP = shutil.which("ffprobe") or os.path.expanduser("~/.local/bin/ffprobe")
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_L = threading.Lock()


def cfg():
    if not os.path.exists(CFG_PATH): raise SystemExit("No encuentro proyecto.json en esta carpeta. Copiá ejemplo/proyecto.json y completalo.")
    return json.load(open(CFG_PATH))


def ruta(*p): return os.path.join(PROY, *p)


for d in ("img", "clips", "voces", "voz", "build", "final"): os.makedirs(ruta(d), exist_ok=True)

# ---------------------------------------------------------------- ApiMart (imágenes, avatar que habla, tomas mudas)
KEY = os.environ.get("APIMART_API_KEY")
BASE = "https://api.apimart.ai/v1"


def _r(m, u, b=None):
    import urllib.request
    if not KEY: raise SystemExit("Falta la variable de entorno APIMART_API_KEY (ponela en ~/.zshrc, nunca en el chat).")
    req = urllib.request.Request(BASE + u, data=json.dumps(b).encode() if b else None, method=m,
                                 headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r: return json.loads(r.read())


def saldo(): return _r("GET", "/user/balance").get("remain_balance")


def esperar(tid, maxw=3600):
    """Las tareas de video pueden quedar en cola: esperar hasta 1 h. Cortar antes y reenviar = pagar dos veces."""
    t0 = time.time()
    while time.time() - t0 < maxw:
        d = _r("GET", f"/tasks/{tid}")["data"]
        if d["status"] == "completed": return d
        if d["status"] == "failed": raise RuntimeError(json.dumps(d)[:400])
        time.sleep(8)
    raise TimeoutError(tid)


def bajar(u, out):
    """El CDN corta descargas: reintenta con curl -C -. NUNCA se regenera por una descarga fallida (se pagaría dos veces)."""
    for _ in range(12):
        r = subprocess.run(["curl", "-sS", "-L", "-C", "-", "--connect-timeout", "20", "--max-time", "300", "-o", out + ".part", u])
        if r.returncode == 0 and os.path.getsize(out + ".part") > 10000: os.replace(out + ".part", out); return out
        time.sleep(10)
    open(ruta("descargas_pendientes.jsonl"), "a").write(json.dumps({"out": out, "url": u}) + "\n")
    raise SystemExit(f"DESCARGA FALLIDA (no regenerar, bajala a mano): {out} {u}")


def video(body, out):
    tid = _r("POST", "/videos/generations", body)["data"][0]["task_id"]
    with _L: open(ruta("tareas.jsonl"), "a").write(json.dumps({"out": out, "tid": tid, "model": body["model"]}) + "\n")
    d = esperar(tid); u = d["result"]["videos"][0]["url"]; u = u[0] if isinstance(u, list) else u
    bajar(u, out)
    with _L: open(ruta("costos.jsonl"), "a").write(json.dumps({"out": os.path.basename(out), "cost": d.get("cost")}) + "\n")
    return d


def imagen(prompt, refs, out):
    tid = _r("POST", "/images/generations", {"model": "gpt-image-2", "prompt": prompt, "image_urls": refs, "size": "9:16", "n": 1})["data"][0]["task_id"]
    d = esperar(tid); u = d["result"]["images"][0]["url"]; u = u[0] if isinstance(u, list) else u
    return bajar(u, out)


# ---------------------------------------------------------------- subida: los modelos piden URL pública de la foto y de la voz
def subir(path):
    """Por defecto usa el hosting gratis de Kie (KIE_API_KEY). Si no tenés Kie, poné la URL pública a mano en subidas.json."""
    C = ruta("subidas.json")
    with _L:
        c = json.load(open(C)) if os.path.exists(C) else {}
        e = c.get(path)
        if isinstance(e, dict) and time.time() - e["t"] < 2 * 86400: return e["u"]      # el hosting vence: se resube a los 2 días
        k = os.environ.get("KIE_API_KEY")
        if not k: raise SystemExit(f"Necesito una URL pública para {path}: definí KIE_API_KEY o cargala en subidas.json como {{\"{path}\": {{\"u\": URL, \"t\": {time.time():.0f}}}}}")
        r = subprocess.run(["curl", "-s", "-X", "POST", "https://kieai.redpandaai.co/api/file-stream-upload", "-H", f"Authorization: Bearer {k}",
                            "-F", f"file=@{ruta(path)}", "-F", "uploadPath=antes-despues"], capture_output=True, text=True)
        j = json.loads(r.stdout)["data"]; u = j.get("downloadUrl") or j.get("fileUrl")
        c[path] = {"u": u, "t": time.time()}; json.dump(c, open(C, "w"), indent=1); return u


# ---------------------------------------------------------------- líneas: relleno al principio y al final
# wan2.7 se traga la 1ª palabra si arranca a hablar en 0 s, y estira el habla hasta el último cuadro.
# Por eso cada línea se manda con una palabra de relleno adelante y otra atrás, y se recortan por alineación forzada.
def relleno(texto):
    c = cfg(); lead = c.get("relleno_inicio", "Mirá,"); tail = c.get("relleno_final", "Bueno, listo.")
    if norm_txt(texto).startswith(norm_txt(lead)[:3]): lead = c.get("relleno_inicio_alt", "Bueno,")     # «Mirá, ¡Mirala…» se funde: usar otro
    return lead, tail


def norm_txt(t): return re.sub(r"[^a-záéíóúñü]", "", t.lower())


def silabas(t):
    t = re.sub(r"\d+", lambda m: "xx" * len(m.group()), t.lower()); n = 0
    for w in re.findall(r"[a-záéíóúüñ]+", t):
        g = re.findall(r"[aeiouáéíóúü]+", w); k = 0
        for x in g: k += 1 + sum(1 for c in x[1:] if c in "aeoáéó" and x[x.index(c) - 1] in "aeoáéó")
        n += max(1, k)
    return n


def duracion(t):
    """segundos enteros 2-15 para wan2.7: ~7,4 sílabas/s + aire. Si dura de más, inventa palabras al final."""
    lead, tail = relleno(t)
    return max(2, min(15, math.ceil(silabas(f"{lead} {t} {tail}") / 7.4 + 0.8)))


def clip(k): return next(c for c in cfg()["clips"] if c["k"] == k)


def dur_archivo(p):
    return float(subprocess.run([FP, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True).stdout)
