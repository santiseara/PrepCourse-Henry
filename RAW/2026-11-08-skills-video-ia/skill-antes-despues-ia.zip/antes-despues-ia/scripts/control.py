"""Control final del MP4 (siempre sobre el render MÁS NUEVO): guion entero con Whisper medium, volumen, cuadros negros/congelados y hoja de cuadros.
Uso: python3 <skill>/scripts/control.py   → imprime diferencias guion/oído y build/hoja_final.jpg"""
import json, os, re, sys, difflib, subprocess, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import cfg, ruta, FF
from norm_es import n
from faster_whisper import WhisperModel
C = cfg(); V = ruta(C.get("salida", "final/VIDEO.mp4"))
r = subprocess.run([FF, "-hide_banner", "-i", V, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
print("volumen:", re.findall(r"I:\s+(-?[\d.]+) LUFS", r)[-1], "LUFS (objetivo -14)")
r = subprocess.run([FF, "-hide_banner", "-i", V, "-vf", "blackdetect=d=0.1,freezedetect=n=0.003:d=0.8", "-an", "-f", "null", "-"], capture_output=True, text=True).stderr
mal = re.findall(r"(black_start:\S+|freeze_start: \S+)", r); print("cuadros negros/congelados:", mal or "ninguno")
subprocess.run([FF, "-v", "error", "-y", "-i", V, "-vf", "fps=0.5,scale=180:-2,tile=9x4", ruta("build", "hoja_final.jpg")])
WM = WhisperModel("medium", compute_type="int8"); s, _ = WM.transcribe(V, language=C.get("idioma", "es"), temperature=0)
oido = " ".join(x.text.strip() for x in s); g = " ".join(c["texto"] for c in C["clips"])
tk = lambda t: [re.sub(r"[^a-z0-9]", "", p.replace("ñ", "n")) for w in t.split() for p in n(w) if re.sub(r"[^a-z0-9]", "", p)]
a, b = tk(g), tk(oido); sm = difflib.SequenceMatcher(None, a, b); print("coincidencia con el guion:", round(sm.ratio(), 3))
for op, i1, i2, j1, j2 in sm.get_opcodes():
    if op != "equal": print(f"  {op:7} guion: {' '.join(a[i1:i2])!r:40} oído: {' '.join(b[j1:j2])!r}")
print("\nSi aparece el relleno («bueno listo», «mirá») es un borde mal cortado. Si una palabra suena distinta, escuchá ese tramo AISLADO antes de regenerar: Whisper confunde en contexto.")
print("hoja:", ruta("build", "hoja_final.jpg"))
