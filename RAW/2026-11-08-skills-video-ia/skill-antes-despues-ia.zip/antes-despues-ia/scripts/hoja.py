"""Hoja de contacto para revisar a ojo: cara, ropa, fondo, saltos de plano y que la persona de atrás haga lo que pide el guion.
Uso: python3 <skill>/scripts/hoja.py clave [clave ...]  → build/hoja.jpg (1 cuadro por segundo, una fila por clip)"""
import sys, os, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import ruta, FF
ks = sys.argv[1:]; fs = []
for k in ks:
    o = ruta("build", f"c_{k}.jpg"); subprocess.run([FF, "-v", "error", "-y", "-i", ruta("clips", k + ".mp4"), "-vf", "fps=1,scale=150:-2,tile=10x1", o]); fs.append(o)
args = sum([["-i", f] for f in fs], [])
subprocess.run([FF, "-v", "error", "-y"] + args + ["-filter_complex", f"vstack={len(fs)}" if len(fs) > 1 else "null", ruta("build", "hoja.jpg")])
print(ruta("build", "hoja.jpg"))
