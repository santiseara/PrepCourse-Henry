"""Fotos de escena con gpt-image-2 (ApiMart). Las que tienen "desde" se hacen EDITANDO otra foto (mismo lugar, misma cara, otro cuerpo).
Uso: python3 <skill>/scripts/imagenes.py [nombre.png ...]   (sin argumentos: todas las que falten; primero las de base, después las editadas)
Para rehacer una: borrá img/<nombre>.png y volvé a correr."""
import sys, os, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import cfg, ruta, imagen, subir

C = cfg(); want = sys.argv[1:]
REAL = C.get("estilo_foto", "Ultra-realistic smartphone photo, natural indoor daylight, real skin texture with pores, no retouching, candid UGC look, vertical 9:16. No text, no captions, no watermark, no UI.")


def go(im):
    out = ruta("img", im["out"])
    if os.path.exists(out): return
    try:
        refs = [subir(f"img/{im['desde']}")] if im.get("desde") else []
        imagen(im["prompt"] + ("" if im.get("desde") else " " + REAL), refs, out); print("OK", im["out"], flush=True)
    except BaseException as e: print("ERR", im["out"], str(e)[:300], flush=True)


for fase in (False, True):                       # 1) fotos base en paralelo  2) las editadas a partir de las base
    js = [im for im in C["imagenes"] if bool(im.get("desde")) == fase and (not want or im["out"] in want)]
    ts = [threading.Thread(target=go, args=(im,)) for im in js]; [t.start() for t in ts]; [t.join() for t in ts]
