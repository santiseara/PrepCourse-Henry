"""Montaje final 1080x1920, 30 fps, SOLO VOZ (cero música, cero efectos de sonido).
Lee proyecto.json + words.json (de alinear.py). Escenas:
  gancho      → selfie con alguien atrás (día 1 / día N): etiqueta chica arriba, zoom suave hacia el fondo para que el cambio se vea.
  presentador → persona a cámara: jump cuts con punch-in alternado, stickers sobrios, botón.
  testimonio  → foto/toma muda a pantalla completa + la persona que habla RECORTADA abajo a la derecha (sin recuadro).
Uso: python3 <skill>/scripts/montar.py                 → final/<salida>.mp4
     python3 <skill>/scripts/montar.py --clave         → build/prev_*.jpg en los momentos clave (revisar ANTES del render)
     python3 <skill>/scripts/montar.py --preview 1,5.2 → cuadros en esos segundos
     python3 <skill>/scripts/montar.py --audio         → rearma solo el audio (después de cambiar voces) y remuxea
Variable AUDIO_DIR=voz_vc para usar la voz pasada por seed-vc (el timeline se mide siempre sobre clips/)."""
import json, os, re, subprocess, math, functools, sys
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import cfg, ruta, FF, SKILL

C = cfg(); WJ = json.load(open(ruta("words.json")))
W, H, FPS, SR = 1080, 1920, 30, 48000
FONT = os.path.join(SKILL, "fuentes"); BLACK, XB, SEMI = (os.path.join(FONT, f) for f in ("Poppins-Black.ttf", "Poppins-ExtraBold.ttf", "Poppins-SemiBold.ttf"))
EMOJI = "/System/Library/Fonts/Apple Color Emoji.ttc"
YEL, GRN, RED, BLUE, INK, WHT = (255, 214, 10), (22, 163, 74), (220, 38, 38), (24, 119, 242), (20, 20, 20), (255, 255, 255)
COLOR = {"rojo": RED, "verde": GRN, "azul": BLUE, "negro": INK}
AUD = os.environ.get("AUDIO_DIR")
CL = {c["k"]: c for c in C["clips"]}
ORDER = [c["k"] for c in C["clips"]]
GAP, KEEP = C.get("pausas", [0.30, 0.12])        # silencios internos > GAP+2·KEEP se recortan dejando KEEP de cada lado, SOLO si la energía confirma silencio


def load(path, start=0, dur=None, sr=SR):
    cmd = [FF, "-v", "error", "-ss", str(start)] + (["-t", str(dur)] if dur else []) + ["-i", path, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]
    return np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).copy()


# ---------------------------------------------------------------- segmentos y tiempos
SEGS, t0 = [], 0.0
for k in ORDER:
    d = WJ[k]; ws = d["words"]; a, b = d["a"], d["b"]
    au = load(ruta("clips", k + ".mp4"), sr=16000); w = 320
    env = np.sqrt(np.convolve(au ** 2, np.ones(w) / w, "same")); thr = 0.15 * np.percentile(env, 95)
    parts, cur = [], a
    for i in range(len(ws) - 1):
        g0, g1 = ws[i][1] + KEEP, ws[i + 1][0] - KEEP
        if g1 - g0 > GAP and env[int(g0 * 16000):int(g1 * 16000)].max() < thr: parts.append((cur, g0)); cur = g1
    parts.append((cur, b))
    cum, P = 0.0, []
    for pa, pb in parts: P.append((pa, pb, cum)); cum += pb - pa

    def to_local(x, P=P):
        for pa, pb, c in P:
            if x <= pb: return c + max(0, x - pa)
        return P[-1][2] + (P[-1][1] - P[-1][0])
    SEGS.append(dict(k=k, parts=P, dur=cum, t0=t0, words=[(to_local(s) + t0, to_local(e) + t0, w) for s, e, w in ws])); t0 += cum
TOTAL = t0; S = {s["k"]: s for s in SEGS}
END = lambda k: TOTAL if k == "fin" else S[k]["t0"] + S[k]["dur"]
print(f"duración total {TOTAL:.2f}s")


def src_time(seg, lt):
    for i, (pa, pb, c) in enumerate(seg["parts"]):
        if lt < c + (pb - pa) or i == len(seg["parts"]) - 1: return pa + (lt - c), i


# ---------------------------------------------------------------- subtítulos: números en cifras, grupos de hasta 3 palabras
NUM = [tuple(x) for x in C.get("numeros", [])]
norm = lambda w: re.sub(r"[^a-záéíóúñü0-9%+]", "", w.lower())


def display_words(words):
    out, i = [], 0
    while i < len(words):
        for ph, rep in NUM:
            n = len(ph.split())
            if [norm(w[2]) for w in words[i:i + n]] == [norm(x) for x in ph.split()]:
                punct = re.sub(r"^.*?([.,!?:;¡¿]*)$", r"\1", words[i + n - 1][2]); out.append((words[i][0], words[i + n - 1][1], rep + punct)); i += n; break
        else: out.append(words[i]); i += 1
    return out


KEY = {norm(x) for x in C.get("palabras_clave", [])}
GROUPS = []
for s in SEGS:
    cur = []
    for w in display_words(s["words"]):
        cur.append(w)
        if re.search(r"[.,!?:;]$", w[2]) or len(cur) == 3 or len(" ".join(x[2] for x in cur)) > 14: GROUPS.append((s["k"], cur)); cur = []
    if cur: GROUPS.append((s["k"], cur))
G = []
for i, (k, ws) in enumerate(GROUPS):
    nxt = GROUPS[i + 1][1][0][0] if i + 1 < len(GROUPS) and GROUPS[i + 1][0] == k else ws[-1][1] + 0.25
    G.append(dict(k=k, words=ws, a=ws[0][0], b=min(nxt, ws[-1][1] + 0.6)))


def word_time(k, target, nth=0):
    hits = [w for w in display_words(S[k]["words"]) if norm(w[2]) == norm(target)]
    if not hits: raise SystemExit(f"[{k}] la palabra «{target}» no está. Palabras: {[w[2] for w in display_words(S[k]['words'])]}")
    return hits[nth][0]


# ---------------------------------------------------------------- gráficos
@functools.lru_cache(None)
def font(path, size): return ImageFont.truetype(path, size)


@functools.lru_cache(None)
def emoji(ch, size):
    if not os.path.exists(EMOJI): return None
    f = ImageFont.truetype(EMOJI, 160); im = Image.new("RGBA", (200, 200), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((100, 100), ch, font=f, embedded_color=True, anchor="mm"); im = im.crop(im.getbbox())
    return im.resize((size, int(size * im.height / im.width)), Image.LANCZOS)


@functools.lru_cache(None)
def word_img(text, size, color, stroke=10, box=None):
    f = font(BLACK, size); l, t, r, b = f.getbbox(text, stroke_width=stroke); pad = 18 if box else 0
    im = Image.new("RGBA", (r - l + 2 * pad + 12, b - t + 2 * pad + 16), (0, 0, 0, 0)); d = ImageDraw.Draw(im); sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    if box:
        ImageDraw.Draw(sh).rounded_rectangle((4, 10, im.width - 4, im.height - 2), 22, fill=(0, 0, 0, 150)); im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(6)))
        d.rounded_rectangle((2, 4, im.width - 6, im.height - 8), 22, fill=box + (255,)); d.text((pad - l + 4, pad - t + 4), text, font=f, fill=INK)
    else:
        ImageDraw.Draw(sh).text((-l + 6, -t + 12), text, font=f, fill=(0, 0, 0, 170), stroke_width=stroke, stroke_fill=(0, 0, 0, 170)); im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(5)))
        d.text((-l + 4, -t + 4), text, font=f, fill=color, stroke_width=stroke, stroke_fill=(0, 0, 0))
    return im


@functools.lru_cache(None)
def tag(text, fg=INK, bg=WHT, size=40, emo=None, padx=28, pady=14, fnt=XB, alpha=245, radius=None):
    """sticker sobrio: píldora blanca chica, texto oscuro, sombra suave, emoji chico opcional."""
    f = font(fnt, size); l, t, r, b = f.getbbox(text); e = emoji(emo, int(size * 0.95)) if emo else None; ew = e.width + 12 if e else 0
    w, h = r - l + 2 * padx + ew, b - t + 2 * pady; rr = radius if radius is not None else h // 2
    im = Image.new("RGBA", (w + 24, h + 28), (0, 0, 0, 0)); sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle((12, 18, w + 12, h + 18), rr, fill=(0, 0, 0, 70)); im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(9)))
    d = ImageDraw.Draw(im); d.rounded_rectangle((12, 10, w + 12, h + 10), rr, fill=bg + (alpha,)); x = 12 + padx
    if e: im.alpha_composite(e, (x, 10 + (h - e.height) // 2)); x += ew
    d.text((x - l, 10 + pady - t), text, font=f, fill=fg); return im


def paste(frame, rgba, cx, cy, scale=1.0, alpha=1.0):
    if scale <= 0.01 or alpha <= 0.01: return
    im = rgba if abs(scale - 1) < 1e-3 else rgba.resize((max(1, int(rgba.width * scale)), max(1, int(rgba.height * scale))), Image.BILINEAR)
    a = np.asarray(im, dtype=np.float32); x0, y0 = int(cx - a.shape[1] / 2), int(cy - a.shape[0] / 2)
    xa, ya, xb, yb = max(0, x0), max(0, y0), min(W, x0 + a.shape[1]), min(H, y0 + a.shape[0])
    if xa >= xb or ya >= yb: return
    sub = a[ya - y0:yb - y0, xa - x0:xb - x0]; al = sub[..., 3:4] / 255.0 * alpha
    frame[ya:yb, xa:xb] = (frame[ya:yb, xa:xb].astype(np.float32) * (1 - al) + sub[..., 2::-1] * al).astype(np.uint8)


def back_out(x): x = min(max(x, 0), 1); c1 = 1.70158; return 1 + (c1 + 1) * (x - 1) ** 3 + c1 * (x - 1) ** 2
def ease(x): x = min(max(x, 0), 1); return x * x * (3 - 2 * x)


def pop(t, t_in, dur=0.28):
    return 0 if t < t_in else 0.35 + 0.65 * back_out((t - t_in) / dur)


def soft(t, t_in, t_out, d=0.18):
    if t < t_in or t >= t_out: return 0, 0
    x = ease((t - t_in) / d); return 0.92 + 0.08 * x, min(x, ease((t_out - t) / 0.15))


class Reader:
    def __init__(self, path, stretch_to=None):
        self.cap = cv2.VideoCapture(path); self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 24
        self.n = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT)); self.idx, self.last = -1, None
        self.stretch = (self.n / self.fps) / stretch_to if stretch_to else 1

    def index(self, t): return min(self.n - 1, max(0, int(t * self.stretch * self.fps)))

    def get(self, t):
        i = self.index(t)
        if i < self.idx: self.cap.set(cv2.CAP_PROP_POS_FRAMES, i); self.idx = i - 1
        while self.idx < i:
            ok, f = self.cap.read()
            if not ok: break
            self.last, self.idx = f, self.idx + 1
        return self.last


def fit(frame, sharp=True):
    h, w = frame.shape[:2]; s = max(W / w, H / h)
    f = cv2.resize(frame, (int(w * s + 0.5), int(h * s + 0.5)), interpolation=cv2.INTER_CUBIC); y, x = (f.shape[0] - H) // 2, (f.shape[1] - W) // 2; f = f[y:y + H, x:x + W]
    return cv2.addWeighted(f, 1.3, cv2.GaussianBlur(f, (0, 0), 1.2), -0.3, 0) if sharp else f


def zoom(f, z, cx=W / 2, cy=H / 2):
    if z <= 1.001: return f
    cw, ch = W / z, H / z; x0 = min(max(cx - cw / 2, 0), W - cw); y0 = min(max(cy - ch / 2, 0), H - ch)
    return cv2.warpAffine(f, np.float32([[z, 0, -x0 * z], [0, z, -y0 * z]]), (W, H), flags=cv2.INTER_LINEAR)


# ---------------------------------------------------------------- etiquetas, stickers, botón
EV = []


def ev(t_in, t_out, img, cx, cy):
    EV.append((t_in, t_out, lambda fr, t: paste(fr, img, cx, cy, *soft(t, t_in, t_out))))


for e in C.get("etiquetas", []):          # «día 01» / «día 21»: chica, blanca, arriba a la izquierda (como los originales que escalan)
    ev(S[e["desde"]]["t0"], END(e["hasta"]), tag(e["texto"], size=44, fnt=SEMI, padx=26, pady=12, radius=18), e.get("x", 215), e.get("y", 330))
for s in C.get("stickers", []):
    t_in = word_time(s["clip"], s["palabra"]) if s.get("palabra") else S[s["clip"]]["t0"] + 0.1
    ev(t_in, END(s.get("hasta", s["clip"])), tag(s["texto"], fg=COLOR.get(s.get("color"), INK), size=s.get("tam", 40), emo=s.get("emoji")), s.get("x", 540), s.get("y", 250))
TEST = [k for k in ORDER if CL[k].get("escena") == "testimonio"]
if TEST and C.get("rotulo"):              # rótulo honesto: si las fotos son IA, se dice
    RIL = tag(C["rotulo"], fg=(240, 240, 240), bg=(0, 0, 0), size=24, fnt=SEMI, padx=18, pady=8, alpha=120)
    for k in TEST: EV.append((S[k]["t0"], END(k), lambda fr, t: paste(fr, RIL, 250, 1870)))
BOT = C.get("boton"); BTN_T = []
if BOT:
    BTN = tag(BOT["texto"], fg=WHT, bg=BLUE, size=50, fnt=BLACK, padx=52, pady=26, radius=24, alpha=255)
    for a in BOT["apariciones"]:
        t_in, t_out = word_time(a["clip"], a["palabra"]), END(a.get("hasta", a["clip"])); BTN_T.append((t_in, t_out))
        def fn(fr, t, t_in=t_in, t_out=t_out):
            s, al = soft(t, t_in, t_out, 0.22); paste(fr, BTN, 540, 1700, s * (1 + 0.025 * math.sin((t - t_in) * 6.5)), al)
        EV.append((t_in, t_out, fn))


def draw_subs(fr, t, k):
    g = next((g for g in G if g["a"] <= t < g["b"]), None)
    if not g: return
    esc = CL[k].get("escena", "presentador")
    y = {"gancho": 1560, "testimonio": 1080}.get(esc, 1180)
    if any(a <= t < b for a, b in BTN_T) and esc == "presentador": y = 1440
    imgs = []
    for (a, b, w) in g["words"]:
        txt = w.upper().strip(); act = a <= t < (b + 0.05) or (t >= b and w == g["words"][-1][2]); kw = norm(w) in KEY
        imgs.append((word_img(txt, 88, INK, 0, box=YEL) if act and kw else word_img(txt, 88, YEL) if act else word_img(txt, 88, WHT if not kw else (255, 236, 150)), act, a))
    gap = 18; total = sum(i[0].width for i in imgs) + gap * (len(imgs) - 1); gs = pop(t, g["a"], 0.22) * min(1.0, 1000 / total); x = 540 - total * gs / 2
    for im, act, a in imgs:
        paste(fr, im, x + im.width * gs / 2, y - (8 if act else 0), gs * (1.0 + (0.10 * back_out((t - a) / 0.16) if act else 0))); x += (im.width + gap) * gs


# ---------------------------------------------------------------- render
ZF = C.get("zoom_fondo", {}); FONDO = ZF.get("centro", [690, 720]); ENTRADA = ZF.get("entradas", {})
HIT = {norm(k): v for k, v in C.get("golpes", {}).items()}


def recortada(src, mask):
    f = fit(src); m = cv2.resize(mask, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_LINEAR)
    m = fit(cv2.cvtColor(m, cv2.COLOR_GRAY2BGR), sharp=False)[..., 0]; m = cv2.GaussianBlur(cv2.erode(m, np.ones((5, 5), np.uint8)), (0, 0), 2.2)
    return Image.fromarray(np.dstack([f[..., ::-1], m]), "RGBA")


def render(times=None):
    out = None if times else subprocess.Popen([FF, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                                               "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", ruta("build", "video.mp4")], stdin=subprocess.PIPE)
    rd = {}; bg = {k: Reader(ruta("clips", CL[k]["fondo_video"]), stretch_to=max(S[k]["dur"], 6.0)) for k in TEST}
    mt = {k: np.load(ruta("build", f"matte_{k}.npz"))["m"] for k in TEST}
    for n in ([int(x * FPS) for x in times] if times else range(int(TOTAL * FPS))):
        t = n / FPS; seg = next((s for s in SEGS if s["t0"] <= t < s["t0"] + s["dur"]), SEGS[-1]); k, lt = seg["k"], t - seg["t0"]
        if k not in rd: rd[k] = Reader(ruta("clips", k + ".mp4"))
        srct, part = src_time(seg, lt); src = rd[k].get(srct); esc = CL[k].get("escena", "presentador")
        if esc == "testimonio":
            fr = zoom(fit(bg[k].get(lt)), 1.0 + 0.06 * lt / seg["dur"], 540, 760); sc = 0.60
            paste(fr, recortada(src, mt[k][min(len(mt[k]) - 1, rd[k].index(srct))]), W - 1080 * sc / 2 + 70, H - 1920 * sc / 2 + 170, sc)
        else:
            fr = fit(src); z = (1.0 if (ORDER.index(k) + part) % 2 == 0 else 1.08) + 0.03 * lt / seg["dur"]
            cx, cy = (440, 1150) if esc == "gancho" else (540, 760)
            for g in G:
                if g["k"] != k: continue
                for a, b, w in g["words"]:
                    amp = HIT.get(norm(w))
                    if amp and 0 <= t - a < 0.7:
                        z += amp * math.sin(min((t - a) / 0.7, 1) * math.pi)
                        if esc == "gancho": cx, cy = cx + (FONDO[0] - cx) * 0.8, cy + (FONDO[1] - cy) * 0.8
            if k in ENTRADA:      # arranca más cerca de la persona de atrás y abre: el cambio se ve sin tapar al que habla
                zi = 1 - ease((lt - 1.4) / 0.8); zi *= ease(lt / 0.3) if ORDER.index(k) > 0 else 1
                z += ENTRADA[k] * zi; cx += (FONDO[0] - cx) * 0.6 * zi; cy += (FONDO[1] - cy) * 0.6 * zi
            fr = zoom(fr, z, cx, cy)
        for (a, b, fn) in EV:
            if a <= t < b: fn(fr, t)
        draw_subs(fr, t, k)
        cv2.rectangle(fr, (0, 0), (W, 10), (40, 40, 40), -1); cv2.rectangle(fr, (0, 0), (int(W * t / TOTAL), 10), (10, 214, 255), -1)
        if times: cv2.imwrite(ruta("build", f"prev_{t:06.2f}.jpg"), cv2.resize(fr, (360, 640), interpolation=cv2.INTER_AREA)); continue
        out.stdin.write(fr.tobytes())
        if n % 300 == 0: print(f"cuadro {n}/{int(TOTAL * FPS)}", flush=True)
    if out: out.stdin.close(); out.wait()


# ---------------------------------------------------------------- audio: solo voz, ganancia fija (loudnorm lineal en 2 pasadas, -14 LUFS)
def audio():
    n = int((TOTAL + 0.3) * SR); voice = np.zeros(n, np.float32); fade = int(0.012 * SR)
    for s in SEGS:
        src = ruta(AUD, s["k"] + ".wav") if AUD else ruta("clips", s["k"] + ".mp4"); full = load(src); ch = []
        for pa, pb, c in s["parts"]:
            x = full[int(pa * SR):int(pb * SR)].copy(); x[:fade] *= np.linspace(0, 1, fade); x[-fade:] *= np.linspace(1, 0, fade); ch.append(x)
        a = np.concatenate(ch)
        if not AUD: a *= 0.10 / np.sqrt(np.mean(a[np.abs(a) > 0.01] ** 2) + 1e-9)         # sin seed-vc: nivela el volumen por clip
        i = int(s["t0"] * SR); voice[i:i + len(a)] += a[:n - i]
    voice.tofile(ruta("build", "voz.f32")); base = [FF, "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", ruta("build", "voz.f32")]
    r = subprocess.run([FF, "-hide_banner", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", ruta("build", "voz.f32"), "-af", "highpass=f=70,loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"], capture_output=True, text=True).stderr
    m = json.loads(r[r.rindex("{"):r.rindex("}") + 1])
    ln = f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true"
    subprocess.run(base + ["-af", f"highpass=f=70,{ln},alimiter=limit=0.89", "-ar", str(SR), ruta("build", "voz.wav")], check=True)


if __name__ == "__main__":
    SAL = ruta(C.get("salida", "final/VIDEO.mp4"))
    if "--clave" in sys.argv:
        ts = []
        for s in SEGS: ts += [s["t0"] + 0.4, s["t0"] + s["dur"] * 0.6]
        render(ts); print("revisá build/prev_*.jpg"); sys.exit()
    if "--preview" in sys.argv: render([float(x) for x in sys.argv[sys.argv.index("--preview") + 1].split(",")]); sys.exit()
    audio()
    if "--audio" not in sys.argv: render()
    subprocess.run([FF, "-v", "error", "-y", "-i", ruta("build", "video.mp4"), "-i", ruta("build", "voz.wav"), "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                    "-shortest", "-movflags", "+faststart", SAL], check=True)
    print("listo", SAL)
