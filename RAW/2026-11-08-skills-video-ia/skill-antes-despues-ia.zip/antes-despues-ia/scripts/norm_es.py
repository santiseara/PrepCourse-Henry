"""Normalización común guion ↔ Whisper: sin tildes, números en palabras (Whisper escribe 47.000, el guion 'cuarenta y siete mil')."""
import re, unicodedata
U="cero uno dos tres cuatro cinco seis siete ocho nueve diez once doce trece catorce quince dieciséis diecisiete dieciocho diecinueve veinte".split()
D={20:"veinte",30:"treinta",40:"cuarenta",50:"cincuenta",60:"sesenta",70:"setenta",80:"ochenta",90:"noventa"}
C={100:"cien",200:"doscientos",300:"trescientos",400:"cuatrocientos",500:"quinientos",600:"seiscientos",700:"setecientos",800:"ochocientos",900:"novecientos"}
V="veintiuno veintidós veintitrés veinticuatro veinticinco veintiséis veintisiete veintiocho veintinueve".split()
def w99(n):
    if n<=20: return U[n]
    if n<30: return V[n-21]
    return D[n//10*10]+("" if n%10==0 else " y "+U[n%10])
def w999(n):
    if n<100: return w99(n)
    if n==100: return "cien"
    h=n//100*100; r=n%100
    return (C[h] if h!=100 else "ciento")+("" if r==0 else " "+w99(r))
def words(n):
    if n<1000: return w999(n)
    m,r=divmod(n,1000)
    return ("mil" if m==1 else w999(m)+" mil")+("" if r==0 else " "+w999(r))
def n(s):
    s=s.lower().replace("glp-1","glp uno").replace("glp1","glp uno").replace("4s","cuatro s").replace("5s","cinco s")
    s=re.sub(r"(\d)\.(\d{3})",r"\1\2",s)
    s=re.sub(r"\d+",lambda m:" "+words(int(m.group()))+" ",s)
    s=unicodedata.normalize("NFD",s); s="".join(ch for ch in s if unicodedata.category(ch)!="Mn")
    return re.sub(r"[^a-z0-9ñ ]"," ",s).split()
if __name__=="__main__":
    for x in ["47.000 pesos","cuarenta y siete mil","360.000","59","90 días","GLP-1","4S","11 años","72 horas","460 mil"]: print(x,"→",n(x))
