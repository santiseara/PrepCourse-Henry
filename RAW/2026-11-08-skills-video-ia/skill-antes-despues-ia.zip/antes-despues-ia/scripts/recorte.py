"""Recorta a la persona que habla (cuadro a cuadro, Mask2Former) para ponerla delante de la foto del testimonio, sin recuadro.
Uso: python3 <skill>/scripts/recorte.py clave [clave ...]  → build/matte_<clave>.npz   (Mac con chip M: usa 'mps'; si no, cpu)"""
import sys, os, numpy as np, torch, cv2, warnings; warnings.filterwarnings("ignore")
from transformers import AutoImageProcessor, Mask2FormerForUniversalSegmentation
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import ruta
dev = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
M = "facebook/mask2former-swin-tiny-coco-instance"; p = AutoImageProcessor.from_pretrained(M); mod = Mask2FormerForUniversalSegmentation.from_pretrained(M).eval().to(dev)
for k in sys.argv[1:]:
    cap = cv2.VideoCapture(ruta("clips", k + ".mp4")); ms = []
    while True:
        ok, fr = cap.read()
        if not ok: break
        H, W = fr.shape[:2]; im = Image.fromarray(cv2.cvtColor(fr, cv2.COLOR_BGR2RGB))
        with torch.no_grad(): o = mod(**{a: b.to(dev) for a, b in p(images=im, return_tensors="pt").items()})
        r = p.post_process_instance_segmentation(o, target_sizes=[(H, W)], threshold=0.4)[0]; seg = r["segmentation"].cpu().numpy()
        ps = [(seg == s["id"]) for s in r["segments_info"] if s["label_id"] == 0]          # clase 0 = persona
        m = max(ps, key=lambda x: x.sum()) if ps else (ms[-1] > 127 if ms else np.zeros((H, W), bool))
        ms.append(cv2.resize(m.astype(np.uint8) * 255, (360, 640), interpolation=cv2.INTER_AREA))
        if len(ms) % 50 == 0: print(k, len(ms), flush=True)
    np.savez_compressed(ruta("build", f"matte_{k}.npz"), m=np.array(ms)); print("OK", k, len(ms))
