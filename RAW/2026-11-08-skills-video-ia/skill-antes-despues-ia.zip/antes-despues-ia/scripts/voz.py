"""Mide si la voz se mantiene entre clips (tono F0, volumen, brillo) por personaje. wan2.7 con la misma voz de referencia igual varía.
Uso: python3 <skill>/scripts/voz.py   (después de alinear.py). Si un clip se sale >±6 % de tono de la mediana de su personaje, conviene seed-vc (ver SKILL.md)."""
import json, os, sys, numpy as np, librosa, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import cfg, ruta
C = cfg(); por = {}
for c in C["clips"]:
    if not c.get("personaje") or not os.path.exists(ruta("voz", c["k"] + ".wav")): continue
    y, sr = librosa.load(ruta("voz", c["k"] + ".wav"), sr=16000); f0, _, _ = librosa.pyin(y, fmin=70, fmax=400, sr=sr)
    por.setdefault(c["personaje"], []).append((c["k"], float(np.nanmedian(f0)), 20 * np.log10(np.sqrt(np.mean(y[np.abs(y) > 0.01] ** 2))),
                                               float(np.median(librosa.feature.spectral_centroid(y=y, sr=sr)))))
for p, xs in por.items():
    med = np.nanmedian([x[1] for x in xs]); print(f"\n{p}: mediana {med:.0f} Hz")
    for k, f, db, br in xs: print(f"  {k:5} F0 {f:6.1f} ({(f / med - 1) * 100:+5.1f} %)  {db:6.1f} dB  brillo {br:5.0f}" + ("   ← se sale" if abs(f / med - 1) > 0.06 else ""))
