# «La apuesta» · guion de la frutinovela de ejemplo

Novela 3D estilo Pixar, personas con cabeza de fruta, 9:16, español rioplatense. Una línea por toma.

| Toma | Quién | Línea |
|---|---|---|
| A1 | Cuñada (cereza) | Cuñada, ¿vas al cumple de mamá? |
| A2 | Cuñada (cereza) | ¿Y qué te vas a poner? |
| A3 | Zulma (papaya) | Todavía no elegí. |
| A4 | Cuñada (cereza) | Elegí ya, gorda, que para tu talle nadie te arregla nada a último momento. |
| A5 | Cuñado (ananá) | ¡Che, Zulma dice que vuelve a entrenar! |
| A6 | Cuñada (cereza) | ¡Es la cuarta vez este año! |
| A7 | Zulma (papaya) | Esta vez la termino. Apostá conmigo. |
| A8 | Cuñada (cereza) | En veintiún días es el cumple de mamá. |
| A9 | Cuñada (cereza) | Si aparecés distinta, te pago doscientos mil pesos. |
| A10 | Cuñada (cereza) | Y si no, no aparecés, gorda. Como las otras tres veces. |
| A11 | Cuñado (ananá) | Poné doscientos mil más míos, que quiero verlo. |
| B1 | (muda) | The papaya-head woman jogs heavily on the treadmill, sweating and panting, wiping her forehead. No dialogue, nobody speaks. |
| K1 | (muda) | The papaya-head woman pokes the lettuce with a fork and sighs, sad. No dialogue, nobody speaks. |
| L1 | Marido (frutilla) | Faltan catorce días y estás igual. |
| L2 | Zulma (papaya) | Amor, no falto un día al gimnasio. |
| L3 | Marido (frutilla) | Ya sé que no faltás. Eso es lo que me saca. |
| L4 | Marido (frutilla) | Guardá mis doscientos mil, gordinflona. Por lo menos la plata queda en casa. |
| C1 | Zulma (papaya) | Ni siquiera es por la plata. Es por la cara que pusieron al tirar el billete. |
| C2 | Doña Rosa (palta) | ¿Qué es esa cara, hija? ¿Qué te pasó? |
| C3 | Zulma (papaya) | Apostaron que no cambio en veintiún días. Y voy perdiendo. |
| C4 | Doña Rosa (palta) | Vas perdiendo porque lo hacés de la forma que no funciona. |
| C5 | Doña Rosa (palta) | Gimnasio y dieta no mueven el músculo correcto. |
| C6 | Doña Rosa (palta) | Después de los treinta, el cuerpo de la mujer se traba. |
| C7 | Doña Rosa (palta) | Cuanto más pesado entrenás, más lo toma como amenaza y retiene todo. |
| C8 | Zulma (papaya) | ¿Y entonces qué es lo que lo mueve? |
| C9 | Doña Rosa (palta) | Pilates en la pared, de Valentina Sosa. |
| C10 | Doña Rosa (palta) | Es entrenadora especializada en el metabolismo de la mujer después de los treinta. |
| C11 | Doña Rosa (palta) | Son veintiún días en una aplicación, veinte minutitos por día. |
| C12 | Doña Rosa (palta) | Una pared y tu celular, nada más. Sin gimnasio, sin dieta, sin cuota. |
| C13 | Doña Rosa (palta) | Activa el músculo que levanta la cola y seca la panza. |
| C14 | Doña Rosa (palta) | Y después el cuerpo sigue quemando solo, hasta dormida. |
| C15 | Zulma (papaya) | ¿Y no tengo que armar la rutina yo sola? |
| C16 | Doña Rosa (palta) | La aplicación ya te da la rutina del día, a la medida de tu cuerpo. |
| C17 | Doña Rosa (palta) | Veintiún días, hija. Justo lo que dura tu apuesta. |
| C18 | Zulma (papaya) | Pasámelo ya mismo, Rosa. |
| D1 | Zulma (papaya) | Empecé sin creerle. Después de todo lo que había probado, era una más. |
| D2 | Zulma (papaya) | Pero la aplicación me decía qué hacer cada día. No tenía que pensar en nada. |
| D3 | Zulma (papaya) | La primera semana ya sentí el cuerpo distinto. |
| J1 | Zulma (papaya) | La segunda, me cerró el jean que ya ni subía. |
| J2 | Zulma (papaya) | Y no pisé un gimnasio ni una vez. |
| N1 | Marido (frutilla) | ¿Y qué es eso que está tirado en el piso? |
| N2 | Zulma (papaya) | Eso es tu apuesta, amor. |
| — | placa | **21 DÍAS DESPUÉS** |
| E1 | Cuñado (ananá) | ¡Zulma! |
| E2 | Marido (frutilla) | Amor… estás distinta. |
| E3 | Zulma (papaya) | Doscientos mil tuyos y doscientos mil de él. |
| E4 | Cuñada (cereza) | Amiga, estaba jodiendo. |
| E5 | Zulma (papaya) | Tiraste el billete en la mesa delante de todos. Gracias. |
| E6 | Zulma (papaya) | Me alcanzó justo para pagar la cuota del gimnasio que di de baja. |
| E7 | Marido (frutilla) | Amor, estás hermosa. Sentate acá conmigo. |
| E8 | Zulma (papaya) | Ahora no. Estoy hablando con las chicas. |
| F1 | Amiga (durazno) | Zulma, decime la verdad. ¿Te operaste? |
| F2 | Zulma (papaya) | Dejé el gimnasio y dejé de pasar hambre. |
| F3 | Amiga (durazno) | Me estás jodiendo, Zulma. |
| F4 | Zulma (papaya) | Veinte minutitos de pilates en la pared, en casa, con la profe Valentina. |
| F5 | Zulma (papaya) | Solo una pared y el celular. Te levanta la cola ya la primera semana. |
| F6 | Zulma (papaya) | Y funciona si pasaste los treinta: está hecho para eso. |
| F7 | Zulma (papaya) | Fueron veintiún días, lo que duró la apuesta. |
| F8 | Amiga (durazno) | Decime cómo empiezo, por favor. |
| F9 | Zulma (papaya) | Tocá en «Más información» y hacé el test gratis. |
| F10 | Zulma (papaya) | Te arma el desafío a la medida de tu cuerpo. |
| F11 | Amiga (durazno) | Lo hago ya mismo, ahora. |
| F12 | Zulma (papaya) | Apurate, que el grupo nuevo está por cerrar. Agradeceme en veintiún días. |
