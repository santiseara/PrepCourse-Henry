"""Frutinovela de ejemplo «La apuesta» (oferta de pilates en casa, Argentina). Copiala como <proyecto>/guion.py y reemplazá todo con tu historia."""

ACENTO = ("Rioplatense Spanish from Buenos Aires with voseo (say 'acá' never 'aquí', 'vos' never 'tú', 'tenés' never 'tienes') "
          "and natural Argentine porteño intonation")
ESTILO = ("3D animated Pixar-style movie scene, characters are human bodies with big expressive fruit heads with human faces, "
          "rich detailed environment, soft warm golden afternoon light")

FOTO = ("Full-body character portrait, 3D animated Pixar-style render, a human body with a big expressive fruit head that has a human face "
        "(big eyes, eyebrows, mouth), detailed fruit skin texture, soft warm light, plain light neutral background. No text, no logos, no watermark.")
CUADRO = ("Vertical 9:16 still frame from a 3D animated Pixar-style movie, people with fruit heads, medium-wide shot with every character "
          "visible from the knees up, rich detailed warm environment, soft golden afternoon light. Keep the exact fruit heads, faces, bodies "
          "and clothes of the characters in the reference images (reference 1, 2, 3 in order). No text, no subtitles, no logos, no watermark.")

PERSONAJES = {
    "zulma_antes": ("A plus-size woman aged 40 with a big ripe yellow-orange PAPAYA head with a human face, two green leaves on top, "
                    "warm brown eyes, sad insecure expression, round belly, wearing a tight grey t-shirt and black leggings."),
    "zulma_pared": ("zulma_antes", "now a bit slimmer, wearing a lilac t-shirt and lilac shorts, barefoot, determined expression"),
    "zulma_despues": ("zulma_antes", "now clearly slimmer with a defined waist, flat belly and an upright confident posture, radiant proud smile, "
                      "wearing a fitted black floral summer dress"),
    "cunada": ("A slim woman aged 38 with a glossy red CHERRY head with a human face and a green stem on top, smug mocking smile, "
               "wearing a burgundy satin blouse and dark jeans."),
    "marido": ("A chubby man aged 42 with a red STRAWBERRY head with a human face and green leaves on top, lazy mocking expression, "
               "wearing a red t-shirt and grey shorts."),
    "cunado": ("A big-bellied man aged 50 with a PINEAPPLE head with a human face and spiky green leaves on top, loud laughing expression, "
               "wearing a white short-sleeve button shirt."),
    "rosa": ("A short plump woman aged 65 with a green AVOCADO head with a human face, round glasses, kind wise motherly smile, "
             "wearing a lilac floral blouse and a white apron."),
    "amiga": ("A woman aged 38 with a pinkish-orange PEACH head with a human face, curious expression, wearing a pastel pink dress."),
}

ESCENAS = {
    "V": ("Close-up, a colourful Argentine neighbourhood greengrocer stall with crates of fruit in the background: only the papaya-head woman in the grey t-shirt (ref 1) "
          "holding a shopping bag, framed from the chest up. Nobody else in the frame.", ["zulma_antes"]),
    "W": ("Close-up, an Argentine backyard party at sunset with colourful bunting in the background: only the peach-head woman in the pink dress (ref 1) sitting on a "
          "white plastic chair, framed from the chest up. Nobody else in the frame.", ["amiga"]),
    "Q": ("Close-up, the same cosy Argentine kitchen with green cabinets: only the cherry-head woman in the burgundy blouse (ref 1) sitting at the lunch table "
          "with a glass of juice, smug smile, framed from the chest up. Nobody else in the frame.", ["cunada"]),
    "P": ("Close-up, the same cosy Argentine kitchen with green cabinets: only the pineapple-head man in the white shirt (ref 1) sitting at the lunch table "
          "with a plate and a glass of juice, laughing loudly, framed from the chest up. Nobody else in the frame.", ["cunado"]),
    "H": ("Close-up, an Argentine living room in the evening: only the strawberry-head man in the red t-shirt (ref 1) sitting on a grey sofa holding his phone, "
          "framed from the chest up. Nobody else in the frame.", ["marido"]),
    "A": ("Midday, a cosy Argentine kitchen with green cabinets, a table with a floral tablecloth, bread, juice and a big lunch. "
          "On the left the cherry-head woman (ref 1) sits at the table; on the right the papaya-head woman (ref 2) stands holding a plate; "
          "in the background the pineapple-head man (ref 3) sits at the end of the table eating calmly with his mouth closed, a neutral relaxed expression, not laughing.",
          ["cunada", "zulma_antes", "cunado"]),
    "B": ("A busy gym with treadmills. The papaya-head woman (ref 1) walks on a treadmill, sweaty and exhausted.", ["zulma_antes"]),
    "K": ("A kitchen counter at night. The papaya-head woman (ref 1) in a floral apron stares sadly at a plastic container of plain lettuce.",
          ["zulma_antes"]),
    "L": ("Evening, an Argentine living room with a grey sofa and a TV. On the left the strawberry-head man (ref 1) sits on the sofa scrolling "
          "his phone; on the right the papaya-head woman (ref 2) in gym clothes stands holding a gym bag.",
          ["marido", "zulma_antes"]),
    "C": ("Morning, a colourful Argentine neighbourhood greengrocer stall with a green and white striped awning and crates full of fruit and vegetables. "
          "Behind the counter on the right the avocado-head woman with glasses (ref 1); in front of the stall on the left the papaya-head woman (ref 2) "
          "with a shopping bag.",
          ["rosa", "zulma_antes"]),
    "D": ("A bright living room with a sofa and plants. The papaya-head woman (ref 1) does a wall sit: her back flat against a clear white wall, knees bent "
          "at 90 degrees, arms stretched forward, natural correct human anatomy, a phone on a small stand on the floor next to her showing a pilates app.",
          ["zulma_pared"]),
    "J": ("A bedroom with a tall mirror in warm sunset light. The papaya-head woman (ref 1), slimmer, wearing a lilac t-shirt and blue jeans, "
          "checks herself in the mirror.",
          ["zulma_pared"]),
    "N": ("Evening, the same living room. On the left the strawberry-head man (ref 1) stands looking at the floor where a pair of gym sneakers and a "
          "torn gym membership card lie; on the right the slimmer papaya-head woman (ref 2) in a lilac t-shirt and jeans smiles.",
          ["marido", "zulma_pared"]),
    "E": ("Afternoon, a family birthday party in an Argentine dining room with a big cake, balloons and food on the table. The confident papaya-head woman "
          "in the black floral dress (ref 1) stands in the middle; on the left the strawberry-head man (ref 2); on the right the pineapple-head man (ref 3) "
          "and the cherry-head woman (ref 4) sitting at the table, open-mouthed.",
          ["zulma_despues", "marido", "cunado", "cunada"]),
    "F": ("Sunset, an Argentine backyard party with colourful bunting, white plastic chairs and snacks. The confident papaya-head woman in the black floral "
          "dress (ref 1) sits on the left; the peach-head woman in the pink dress (ref 2) sits on the right, leaning towards her. Only these two women are in the yard, nobody else in the background.",
          ["zulma_despues", "amiga"]),
}

VOZ = {
    "Z": ("F", "Zulma, a 40-year-old Argentine woman with a soft, warm, medium-low alto voice, gentle and never high-pitched"),
    "K": ("F", "the sister-in-law, a 38-year-old Argentine woman with a bright, high-pitched, sharp, mocking voice"),
    "R": ("F", "Doña Rosa, a 65-year-old Argentine woman with a deep, raspy, slow, motherly old-lady voice"),
    "A": ("F", "the friend, a 35-year-old Argentine woman with a lively, fast, girlish, excited voice"),
    "M": ("M", "the husband, a 42-year-old Argentine MAN with a very deep, low, lazy, mocking male baritone voice"),
    "C": ("M", "the brother-in-law, a 50-year-old Argentine MAN with a loud, hoarse, deep male laughing voice"),
}

POS = {
    "A": {"K": "the cherry-head woman in the burgundy blouse", "Z": "the papaya-head woman in the grey t-shirt",
          "C": "the pineapple-head man in the white shirt"},
    "L": {"M": "the strawberry-head man on the sofa", "Z": "the papaya-head woman with the gym bag"},
    "C": {"R": "the avocado-head woman with glasses behind the counter", "Z": "the papaya-head woman with the shopping bag"},
    "D": {"Z": "the papaya-head woman on the yoga mat"},
    "J": {"Z": "the papaya-head woman in jeans"},
    "N": {"M": "the strawberry-head man in the red t-shirt", "Z": "the papaya-head woman in jeans"},
    "E": {"Z": "the papaya-head woman in the black floral dress", "M": "the strawberry-head man in the red t-shirt",
          "C": "the pineapple-head man in the white shirt", "K": "the cherry-head woman in the burgundy blouse"},
    "F": {"Z": "the papaya-head woman in the black floral dress", "A": "the peach-head woman in the pink dress"},
}

TOMAS = [
    # A · Cocina: la apuesta
    ("A1", "A", "The cherry-head woman looks up at the papaya-head woman with a fake sweet smile.",
     [("K", "fake sweet", "Cuñada, ¿vas al cumple de mamá?")]),
    ("A2", "A", "The cherry-head woman tilts her head with a playful smile, sipping her juice.",
     [("K", "teasing", "¿Y qué te vas a poner?")]),
    ("A3", "prev", "The papaya-head woman lowers her eyes, holding the plate, a little sad.",
     [("Z", "shy, quietly", "Todavía no elegí.")]),
    ("A4", "A", "The cherry-head woman points at her with a fork, laughing.",
     [("K", "mocking, cruel", "Elegí ya, gorda, que para tu talle nadie te arregla nada a último momento.")]),
    ("A5", "prev", "The pineapple-head man laughs out loud and slaps the table.",
     [("C", "loud, laughing", "¡Che, Zulma dice que vuelve a entrenar!")]),
    ("A6", "prev", "The cherry-head woman rolls her eyes and laughs.",
     [("K", "mocking", "¡Es la cuarta vez este año!")]),
    ("A7", "A", "The papaya-head woman puts the plate down and raises her chin, hurt but determined.",
     [("Z", "determined", "Esta vez la termino. Apostá conmigo.")]),
    ("A8", "prev", "The cherry-head woman leans forward with a smug smile.",
     [("K", "smug", "En veintiún días es el cumple de mamá.")]),
    ("A9", "prev", "The cherry-head woman slaps a banknote on the table.",
     [("K", "smug, challenging", "Si aparecés distinta, te pago doscientos mil pesos.")]),
    ("A10", "Q", "The cherry-head woman leans back, crossing her arms. Tight static close-up for the whole video: the camera never moves or zooms out and no other people ever appear in the frame.",
     [("K", "cruel", "Y si no, no aparecés, gorda. Como las otras tres veces.")]),
    ("A11", "P", "The pineapple-head man calmly puts another banknote on the table with a smug grin. Tight static close-up for the whole video: the camera never moves or zooms out and no other people ever appear in the frame.",
     [("C", "deep, smug, calm", "Poné doscientos mil más míos, que quiero verlo.")]),
    # B · gimnasio (muda) · K · tupper (muda)
    ("B1", "B", "The papaya-head woman jogs heavily on the treadmill, sweating and panting, wiping her forehead. No dialogue, nobody speaks.", []),
    ("K1", "K", "The papaya-head woman pokes the lettuce with a fork and sighs, sad. No dialogue, nobody speaks.", []),
    # L · living con el marido
    ("L1", "L", "The strawberry-head man doesn't look up from his phone.",
     [("M", "lazy, mocking", "Faltan catorce días y estás igual.")]),
    ("L2", "prev", "The papaya-head woman drops the gym bag, frustrated.",
     [("Z", "frustrated", "Amor, no falto un día al gimnasio.")]),
    ("L3", "H", "The strawberry-head man shrugs, still looking at his phone.",
     [("M", "annoyed", "Ya sé que no faltás. Eso es lo que me saca.")]),
    ("L4", "prev", "The strawberry-head man smirks and waves his hand.",
     [("M", "mocking", "Guardá mis doscientos mil, gordinflona. Por lo menos la plata queda en casa.")]),
    # C · verdulería: Doña Rosa revela el mecanismo
    ("C1", "C", "The papaya-head woman picks a fruit from a crate, talking half to herself, sad.",
     [("Z", "sad, quietly", "Ni siquiera es por la plata. Es por la cara que pusieron al tirar el billete.")]),
    ("C2", "prev", "The avocado-head woman leans over the counter, worried.",
     [("R", "motherly", "¿Qué es esa cara, hija? ¿Qué te pasó?")]),
    ("C3", "C", "The papaya-head woman shrugs, eyes watering.",
     [("Z", "sad", "Apostaron que no cambio en veintiún días. Y voy perdiendo.")]),
    ("C4", "prev", "The avocado-head woman shakes her head and wipes her hands on her apron.",
     [("R", "wise, calm", "Vas perdiendo porque lo hacés de la forma que no funciona.")]),
    ("C5", "C", "The avocado-head woman counts on her fingers, explaining.",
     [("R", "wise", "Gimnasio y dieta no mueven el músculo correcto.")]),
    ("C6", "prev", "The avocado-head woman gestures with both hands, explaining.",
     [("R", "wise", "Después de los treinta, el cuerpo de la mujer se traba.")]),
    ("C7", "C", "The avocado-head woman raises a finger, serious.",
     [("R", "serious", "Cuanto más pesado entrenás, más lo toma como amenaza y retiene todo.")]),
    ("C8", "V", "The papaya-head woman leans in, curious.",
     [("Z", "curious", "¿Y entonces qué es lo que lo mueve?")]),
    ("C9", "C", "The avocado-head woman smiles and takes out her phone.",
     [("R", "warm", "Pilates en la pared, de Valentina Sosa.")]),
    ("C10", "prev", "The avocado-head woman nods, sure of herself.",
     [("R", "warm", "Es entrenadora especializada en el metabolismo de la mujer después de los treinta.")]),
    ("C11", "C", "The avocado-head woman shows her phone screen with a pilates app.",
     [("R", "warm", "Son veintiún días en una aplicación, veinte minutitos por día.")]),
    ("C12", "prev", "The avocado-head woman points at the wall of the stall.",
     [("R", "warm", "Una pared y tu celular, nada más. Sin gimnasio, sin dieta, sin cuota.")]),
    ("C13", "C", "The avocado-head woman smiles and nods, sure of herself.",
     [("R", "confident", "Activa el músculo que levanta la cola y seca la panza.")]),
    ("C14", "prev", "The avocado-head woman makes a sleeping gesture with her hands.",
     [("R", "confident", "Y después el cuerpo sigue quemando solo, hasta dormida.")]),
    ("C15", "C", "The papaya-head woman frowns, worried.",
     [("Z", "worried", "¿Y no tengo que armar la rutina yo sola?")]),
    ("C16", "prev", "The avocado-head woman shakes her head, smiling.",
     [("R", "warm", "La aplicación ya te da la rutina del día, a la medida de tu cuerpo.")]),
    ("C17", "C", "The avocado-head woman takes her hand, tender.",
     [("R", "tender", "Veintiún días, hija. Justo lo que dura tu apuesta.")]),
    ("C18", "V", "The papaya-head woman takes out her phone, hopeful.",
     [("Z", "hopeful", "Pasámelo ya mismo, Rosa.")]),
    # D · la pared (le habla a cámara mientras entrena)
    ("D1", "D", "The papaya-head woman holds the wall sit, breathing, talking to the camera. Same pose and natural anatomy for the whole video.",
     [("Z", "honest, a bit tired", "Empecé sin creerle. Después de todo lo que había probado, era una más.")]),
    ("D2", "prev", "The papaya-head woman slowly stands up from the wall sit and stretches her arms, talking to the camera. Natural anatomy for the whole video.",
     [("Z", "surprised", "Pero la aplicación me decía qué hacer cada día. No tenía que pensar en nada.")]),
    ("D3", "D", "The papaya-head woman goes back down into the wall sit, smiling at the camera. Natural anatomy for the whole video.",
     [("Z", "happy", "La primera semana ya sentí el cuerpo distinto.")]),
    ("J1", "J", "The papaya-head woman buttons the jeans easily and turns to the mirror, amazed.",
     [("Z", "amazed, happy", "La segunda, me cerró el jean que ya ni subía.")]),
    ("J2", "prev", "The papaya-head woman turns to the camera, proud.",
     [("Z", "proud", "Y no pisé un gimnasio ni una vez.")]),
    ("N1", "N", "The strawberry-head man points at the floor, confused.",
     [("M", "confused", "¿Y qué es eso que está tirado en el piso?")]),
    ("N2", "prev", "The papaya-head woman smiles and walks past him.",
     [("Z", "playful, confident", "Eso es tu apuesta, amor.")]),
    # E · el cumpleaños
    ("E1", "E", "The pineapple-head man at the table opens his eyes wide in shock. Only the four characters already in the picture, no new characters appear.",
     [("C", "shocked, loud", "¡Zulma!")]),
    ("E2", "prev", "The strawberry-head man stares at her, mouth open.",
     [("M", "amazed", "Amor… estás distinta.")]),
    ("E3", "E", "The papaya-head woman stretches out her open hand towards the table, smiling.",
     [("Z", "confident", "Doscientos mil tuyos y doscientos mil de él.")]),
    ("E4", "prev", "The cherry-head woman laughs nervously, embarrassed.",
     [("K", "nervous", "Amiga, estaba jodiendo.")]),
    ("E5", "E", "The papaya-head woman takes the banknotes from the cherry-head woman's hand.",
     [("Z", "calm, firm", "Tiraste el billete en la mesa delante de todos. Gracias.")]),
    ("E6", "prev", "The papaya-head woman counts the banknotes with a smile.",
     [("Z", "playful", "Me alcanzó justo para pagar la cuota del gimnasio que di de baja.")]),
    ("E7", "E", "The strawberry-head man pats the chair next to him, smitten. Everyone stays in place, nobody walks, the papaya-head woman keeps her yellow-orange papaya head.",
     [("M", "smitten", "Amor, estás hermosa. Sentate acá conmigo.")]),
    ("E8", "prev", "The papaya-head woman waves him off with a smile, staying in her place behind the table. Nobody walks, the papaya-head woman keeps her yellow-orange papaya head.",
     [("Z", "playful", "Ahora no. Estoy hablando con las chicas.")]),
    # F · patio con la amiga
    ("F1", "F", "The peach-head woman grabs her arm and whispers.",
     [("A", "curious, whispering", "Zulma, decime la verdad. ¿Te operaste?")]),
    ("F2", "prev", "The papaya-head woman laughs.",
     [("Z", "proud", "Dejé el gimnasio y dejé de pasar hambre.")]),
    ("F3", "W", "The peach-head woman leans back, incredulous.",
     [("A", "incredulous", "Me estás jodiendo, Zulma.")]),
    ("F4", "prev", "The papaya-head woman explains, counting on her fingers.",
     [("Z", "confident", "Veinte minutitos de pilates en la pared, en casa, con la profe Valentina.")]),
    ("F5", "F", "The papaya-head woman taps her phone, smiling.",
     [("Z", "confident", "Solo una pared y el celular. Te levanta la cola ya la primera semana.")]),
    ("F6", "prev", "The papaya-head woman points at herself.",
     [("Z", "confident", "Y funciona si pasaste los treinta: está hecho para eso.")]),
    ("F7", "F", "The papaya-head woman smiles, proud.",
     [("Z", "proud", "Fueron veintiún días, lo que duró la apuesta.")]),
    ("F8", "prev", "The peach-head woman grabs her hands, desperate.",
     [("A", "desperate, excited", "Decime cómo empiezo, por favor.")]),
    ("F9", "F", "The papaya-head woman shows her phone screen to her friend.",
     [("Z", "warm", "Tocá en «Más información» y hacé el test gratis.")]),
    ("F10", "prev", "The papaya-head woman taps the phone screen.",
     [("Z", "warm", "Te arma el desafío a la medida de tu cuerpo.")]),
    ("F11", "W", "The peach-head woman takes out her phone, excited.",
     [("A", "excited", "Lo hago ya mismo, ahora.")]),
    ("F12", "prev", "The papaya-head woman winks at her, smiling.",
     [("Z", "playful", "Apurate, que el grupo nuevo está por cerrar. Agradeceme en veintiún días.")]),
]

PLACAS = {"E1": "21 DÍAS DESPUÉS"}
CTA = ("Tocá en", "Más información")
