"""Cosas comunes de la skill fruti-novela: cliente ApiMart, subida de imágenes, ffmpeg, carga del guion y normalización de texto.
La clave va en la variable de entorno APIMART_API_KEY (nunca escrita en archivos). KIE_API_KEY es opcional (solo para subir imágenes)."""
import json, os, re, sys, time, shutil, subprocess, unicodedata, importlib.util, urllib.request

FF = shutil.which("ffmpeg") or os.path.expanduser("~/.local/bin/ffmpeg")
FP = shutil.which("ffprobe") or os.path.expanduser("~/.local/bin/ffprobe")
API = "https://api.apimart.ai/v1"


# ---------- proyecto y guion ----------
def proyecto(path):
    """Devuelve (carpeta del proyecto, módulo del guion). Acepta la carpeta o el guion.py directamente."""
    path = os.path.abspath(path)
    g = path if path.endswith(".py") else os.path.join(path, "guion.py")
    if not os.path.exists(g):
        sys.exit(f"No encuentro el guion: {g}")
    spec = importlib.util.spec_from_file_location("guion", g)
    G = importlib.util.module_from_spec(spec); spec.loader.exec_module(G)
    for k in ("ACENTO", "VOZ", "POS", "TOMAS", "ESCENAS", "PERSONAJES"):
        if not hasattr(G, k):
            sys.exit(f"Al guion le falta {k} (mirá plantillas/guion_ejemplo.py)")
    G.ESTILO = getattr(G, "ESTILO", "Realistic candid smartphone footage")
    G.PLACAS = getattr(G, "PLACAS", {})
    G.CTA = getattr(G, "CTA", ("Tocá en", "Más información"))
    G.LINEAS = [(t[0], p, e, x) for t in G.TOMAS for p, e, x in t[3]]
    return os.path.dirname(g), G


def genero(G, c):
    """'M' o 'F' según VOZ[c] = ("F", "descripción")."""
    return G.VOZ[c][0].upper()


def voz(G, c):
    return G.VOZ[c][1]


# ---------- ApiMart ----------
def _key():
    k = os.environ.get("APIMART_API_KEY")
    if not k:
        sys.exit("Falta APIMART_API_KEY. Exportala en la terminal: export APIMART_API_KEY=...")
    return k


def _r(m, u, b=None):
    req = urllib.request.Request(API + u, data=json.dumps(b).encode() if b else None, method=m,
                                 headers={"Authorization": f"Bearer {_key()}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read())


def saldo():
    try:
        return _r("GET", "/user/balance")["remain_balance"]
    except Exception as e:
        return f"? ({e})"


def esperar(tid, maxw=3600):
    """Espera larga a propósito: cortar antes y reenviar = pagar dos veces."""
    t0 = time.time()
    while time.time() - t0 < maxw:
        d = _r("GET", f"/tasks/{tid}")["data"]
        if d["status"] == "completed":
            return d
        if d["status"] == "failed":
            raise RuntimeError(json.dumps(d)[:500])
        time.sleep(8)
    raise TimeoutError(tid)


def bajar(u, out):
    """El CDN corta: reintenta con curl -C - y NUNCA vuelve a generar por una descarga fallida."""
    for _ in range(12):
        r = subprocess.run(["curl", "-sS", "-L", "-C", "-", "--connect-timeout", "20", "--max-time", "300", "-o", out + ".part", u])
        if r.returncode == 0 and os.path.exists(out + ".part") and os.path.getsize(out + ".part") > 10000:
            os.replace(out + ".part", out); return out
        time.sleep(10)
    with open(os.path.join(os.path.dirname(out), "descargas_pendientes.jsonl"), "a") as f:
        f.write(json.dumps({"out": out, "url": u}) + "\n")
    raise SystemExit(f"DESCARGA FALLIDA (no regenerar, bajala a mano): {out} {u}")


def _url(d, tipo):
    u = d["result"][tipo][0]["url"]
    return u[0] if isinstance(u, list) else u


def video(body, out, log):
    tid = _r("POST", "/videos/generations", body)["data"][0]["task_id"]
    d = esperar(tid)
    bajar(_url(d, "videos"), out)
    with open(log, "a") as f:
        f.write(json.dumps({"out": os.path.basename(out), "cost": d.get("cost"), "task": tid}) + "\n")
    print("OK", os.path.basename(out), "costo", d.get("cost"), flush=True)
    return d


def imagen(body, out, log):
    tid = _r("POST", "/images/generations", body)["data"][0]["task_id"]
    d = esperar(tid, 900)
    bajar(_url(d, "images"), out)
    with open(log, "a") as f:
        f.write(json.dumps({"out": os.path.basename(out), "cost": d.get("cost"), "task": tid}) + "\n")
    print("OK", os.path.basename(out), "costo", d.get("cost"), flush=True)
    return out


# ---------- subir imágenes (ApiMart pide URL pública) ----------
_CACHE = {}


def subir(path):
    """Kie si hay KIE_API_KEY; si no, catbox.moe (público y gratis). Cachea por archivo+fecha."""
    k = (path, os.path.getmtime(path))
    if k in _CACHE:
        return _CACHE[k]
    kie = os.environ.get("KIE_API_KEY")
    if kie:
        r = subprocess.run(["curl", "-s", "-X", "POST", "https://kieai.redpandaai.co/api/file-stream-upload",
                            "-H", f"Authorization: Bearer {kie}", "-F", f"file=@{path}", "-F", "uploadPath=fruti-novela"],
                           capture_output=True, text=True)
        j = json.loads(r.stdout)["data"]; u = j.get("downloadUrl") or j.get("fileUrl")
    else:
        r = subprocess.run(["curl", "-s", "-F", "reqtype=fileupload", "-F", f"fileToUpload=@{path}", "https://catbox.moe/user/api.php"],
                           capture_output=True, text=True)
        u = r.stdout.strip()
        if not u.startswith("http"):
            sys.exit(f"No pude subir {path}: {r.stdout[:200]} (probá con KIE_API_KEY)")
    _CACHE[k] = u
    return u


# ---------- ffmpeg ----------
def dur(p):
    return float(subprocess.run([FP, "-v", "0", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True).stdout)


def ultimo_cuadro(clip):
    png = clip.replace(".mp4", "_ult.png")
    subprocess.run([FF, "-v", "error", "-y", "-sseof", "-0.15", "-i", clip, "-frames:v", "1", png], check=True)
    return png


def audio(p, sr=16000):
    import numpy as np
    return np.frombuffer(subprocess.run([FF, "-v", "error", "-i", p, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"],
                                        capture_output=True).stdout, np.float32).copy()


# ---------- normalización guion <-> Whisper ----------
_U = "cero uno dos tres cuatro cinco seis siete ocho nueve diez once doce trece catorce quince dieciséis diecisiete dieciocho diecinueve veinte".split()
_D = {20: "veinte", 30: "treinta", 40: "cuarenta", 50: "cincuenta", 60: "sesenta", 70: "setenta", 80: "ochenta", 90: "noventa"}
_C = {100: "cien", 200: "doscientos", 300: "trescientos", 400: "cuatrocientos", 500: "quinientos", 600: "seiscientos",
      700: "setecientos", 800: "ochocientos", 900: "novecientos"}
_V = "veintiuno veintidós veintitrés veinticuatro veinticinco veintiséis veintisiete veintiocho veintinueve".split()


def _w99(n):
    if n <= 20: return _U[n]
    if n < 30: return _V[n - 21]
    return _D[n // 10 * 10] + ("" if n % 10 == 0 else " y " + _U[n % 10])


def _w999(n):
    if n < 100: return _w99(n)
    if n == 100: return "cien"
    h, r = n // 100 * 100, n % 100
    return (_C[h] if h != 100 else "ciento") + ("" if r == 0 else " " + _w99(r))


def _words(n):
    if n < 1000: return _w999(n)
    if n >= 1_000_000: return str(n)
    m, r = divmod(n, 1000)
    return ("mil" if m == 1 else _w999(m) + " mil") + ("" if r == 0 else " " + _w999(r))


def norm(s):
    """Sin tildes, minúsculas, números en palabras. Devuelve lista de palabras."""
    s = s.lower()
    s = re.sub(r"(\d)\.(\d{3})", r"\1\2", s)
    s = re.sub(r"\d+", lambda m: " " + _words(int(m.group())) + " ", s)
    s = unicodedata.normalize("NFD", s); s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return re.sub(r"[^a-z0-9ñ ]", " ", s).split()
