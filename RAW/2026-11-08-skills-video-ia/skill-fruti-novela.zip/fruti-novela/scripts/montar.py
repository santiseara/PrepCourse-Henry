"""Paso 5 · Montaje: cada toma recortada a su tramo hablado (bordes de verif.py), huecos largos entre palabras achicados,
tomas mudas de hasta MUDA_MAX s, placas de tiempo («6 MESES ANTES») sobre negro, subtítulo chico blanco en minúsculas por
línea (estilo novela), placa final con flecha y CTA. Sin música ni SFX. Audio a -14 LUFS con ganancia fija.
Ajustes a mano opcionales en <proyecto>/ajustes.json: {"A3": {"a": 0.4, "b": 5.1}}
Uso: python3 montar.py <proyecto>  → <proyecto>/FINAL.mp4"""
import json, os, sys, re, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comun as C

P, G = C.proyecto(sys.argv[1]); FF = C.FF
BOR = json.load(open(f"{P}/bordes.json"))
AJ = json.load(open(f"{P}/ajustes.json")) if os.path.exists(f"{P}/ajustes.json") else {}
MUDA_MAX = float(os.environ.get("MUDA_MAX", "5.0")); PAUSA = float(os.environ.get("PAUSA", "0.9")); PRE, POST = 0.08, 0.16
W, H = 720, 1280; B = f"{P}/build"; os.makedirs(B, exist_ok=True)
FONT = next((f for f in ["/System/Library/Fonts/Supplemental/Arial Bold.ttf", "/Library/Fonts/Arial Bold.ttf",
                         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "C:/Windows/Fonts/arialbd.ttf"] if os.path.exists(f)), None)
ENC = ["-c:v", "libx264", "-crf", "17", "-preset", "fast", "-c:a", "aac", "-ar", "48000", "-ac", "2"]


def ts(x): return f"{int(x // 3600)}:{int(x % 3600 // 60):02d}:{x % 60:05.2f}"
def sub_txt(t): return re.sub(r"\s+", " ", re.sub(r"[¿?¡!.,;:…\"«»—]", "", t.lower())).strip()
def esc(t): return t.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\u2019")


def placa(out, lineas, d, color="white", size=64):
    vf = []
    y0 = H // 2 - (len(lineas) * (size + 16)) // 2
    for i, l in enumerate(lineas):
        vf.append(f"drawtext=fontfile='{FONT}':text='{esc(l)}':fontsize={size}:fontcolor={color}:x=(w-tw)/2:y={y0 + i * (size + 16)}")
    subprocess.run([FF, "-v", "error", "-y", "-f", "lavfi", "-i", f"color=c=black:s={W}x{H}:d={d}:r=30", "-f", "lavfi",
                    "-i", "anullsrc=r=48000:cl=stereo", "-vf", ",".join(vf), "-t", str(d), *ENC, out], check=True)
    return out


faltan = [t[0] for t in G.TOMAS if t[0] not in BOR or "a" not in BOR[t[0]]]
if faltan: sys.exit(f"Faltan verificar (verif.py): {' '.join(faltan)}")
parts, subs, t = [], [], 0.0
for tid, img, acc, dlg in G.TOMAS:
    if tid in G.PLACAS:
        pl = placa(f"{B}/placa_{tid}.mp4", G.PLACAS[tid].split("\n"), 1.6); parts.append(pl); t += 1.6
    bo = BOR[tid]; clip = f"{P}/clips/{tid}.mp4"
    ww = [w for l in bo.get("lineas", []) for w in l[4]]
    a0 = max(0.0, ww[0][0] - PRE) if ww else bo["a"]; b0 = min(bo["dur"], ww[-1][1] + POST) if ww else bo["b"]
    a, b = AJ.get(tid, {}).get("a", a0), AJ.get(tid, {}).get("b", b0)
    if not dlg: a, b = 0.6, min(bo["b"], 0.6 + MUDA_MAX)
    seg = f"{B}/{tid}.mp4"
    ws = [w for l in bo.get("lineas", []) for w in l[4] if a <= w[0] <= b]
    ints = [[a, b]]
    for w1, w2 in zip(ws, ws[1:]):
        if w2[0] - w1[1] > PAUSA: ints[-1][1] = w1[1] + 0.16; ints.append([w2[0] - 0.08, b])

    def mapa(x):
        acc_t = 0.0
        for s0, s1 in ints:
            if x <= s1: return acc_t + max(0.0, x - s0)
            acc_t += s1 - s0
        return acc_t
    subsegs = []
    for k, (s0, s1) in enumerate(ints):
        ss = seg if len(ints) == 1 else f"{B}/{tid}_{k}.mp4"
        subprocess.run([FF, "-v", "error", "-y", "-ss", f"{s0:.3f}", "-to", f"{s1:.3f}", "-i", clip,
                        "-af", f"afade=t=in:d=0.03,afade=t=out:st={max(0, s1 - s0 - 0.06):.3f}:d=0.06",
                        "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,fps=30", *ENC, ss], check=True)
        subsegs.append(ss)
    if len(ints) > 1:
        open(f"{B}/{tid}_l.txt", "w").write("".join(f"file '{x}'\n" for x in subsegs))
        subprocess.run([FF, "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", f"{B}/{tid}_l.txt", "-c", "copy", seg], check=True)
    for l0, l1, p, txt, wl in bo.get("lineas", []):
        orig = sub_txt(txt).upper().split(); wl = [w for w in wl if a - 0.01 <= w[0] <= b]
        if len(orig) != len(wl): orig = [w[2].upper() for w in wl]
        k = 0
        while k < len(wl):
            n = 3 if len(wl) - k > 4 else (len(wl) - k if len(wl) - k <= 3 else 2)
            g = wl[k:k + n]; tx = " ".join(orig[k:k + n])
            while len(tx) > 18 and n > 1: n -= 1; g = wl[k:k + n]; tx = " ".join(orig[k:k + n])
            subs.append((t + mapa(g[0][0]), t + mapa(g[-1][1]) + 0.12, tx)); k += n
    parts.append(seg); t += C.dur(seg)
parts.append(placa(f"{B}/zz_fin.mp4", ["↓", *G.CTA], 2.5, color="0xF5A623", size=56)); t += 2.5
lst = f"{B}/lista.txt"; open(lst, "w").write("".join(f"file '{p}'\n" for p in parts))
raw = f"{B}/raw.mp4"
subprocess.run([FF, "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", raw], check=True)
for j in range(len(subs) - 1): subs[j] = (subs[j][0], min(subs[j][1], subs[j + 1][0]), subs[j][2])
hdr = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: S,Arial Black,58,&H0000FFFF,&H0000FFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,5,2,2,40,40,330,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
ass = f"{B}/subs.ass"
open(ass, "w").write(hdr + "".join(f"Dialogue: 0,{ts(x0)},{ts(x1)},S,,0,0,0,,{x}\n" for x0, x1, x in subs))
m = subprocess.run([FF, "-hide_banner", "-i", raw, "-af", "loudnorm=I=-14:TP=-1.5:print_format=json", "-f", "null", "-"],
                   capture_output=True, text=True).stderr
I = float(re.search(r'"input_i"\s*:\s*"([-\d.]+)"', m).group(1)); gdb = -14 - I
out = f"{P}/FINAL.mp4"
subprocess.run([FF, "-v", "error", "-y", "-i", raw, "-vf", f"ass={ass}", "-af", f"volume={gdb:.2f}dB,alimiter=limit=0.89",
                "-c:v", "libx264", "-crf", "19", "-preset", "medium", "-c:a", "aac", "-b:a", "160k", "-ar", "48000",
                "-movflags", "+faststart", out], check=True)
print("OK", out, round(t, 1), "s", f"ganancia {gdb:+.1f} dB")
