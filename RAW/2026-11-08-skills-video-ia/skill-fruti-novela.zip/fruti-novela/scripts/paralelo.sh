#!/bin/bash
# Genera en paralelo TODAS las tomas que falten (cada una arranca de la imagen de su escena, MAX_CADENA=0) y reintenta
# hasta 4 veces las que frene el filtro (no cobran). Uso: paralelo.sh <proyecto> [simultaneas=15]
DIR="$(cd "$(dirname "$0")" && pwd)"; P="$1"; N="${2:-15}"
for i in 1 2 3 4; do
  F=$(cd "$P" && python3 -c "import guion as g, os; print(' '.join(t[0] for t in g.TOMAS if not os.path.exists(f'clips/{t[0]}.mp4')))")
  [ -z "$F" ] && break
  echo "intento $i: $F"
  echo $F | tr ' ' '\n' | MAX_CADENA=0 xargs -P "$N" -I{} sh -c "python3 '$DIR/gen.py' '$P' {} 2>&1 | grep -E 'OK|FALLO' | cut -c1-60"
done
F=$(cd "$P" && python3 -c "import guion as g, os; print(' '.join(t[0] for t in g.TOMAS if not os.path.exists(f'clips/{t[0]}.mp4')))")
[ -n "$F" ] && echo "SIGUEN FRENADAS (cambiar la línea o la imagen, ver SKILL.md §7): $F" || echo "TODAS LISTAS"
