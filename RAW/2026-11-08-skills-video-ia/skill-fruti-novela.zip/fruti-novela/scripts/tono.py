"""Tono (F0) de cada línea contra la mediana de su personaje. Marca cambios grandes de voz entre tomas.
Uso: python3 tono.py <proyecto>   (correr después de verif.py)
Más de ±25 % o un hombre por encima de 175 Hz = escuchar y, si es otra voz, regenerar (SKILL.md §7)."""
import sys, json, os, numpy as np, librosa
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import comun as C
P, G = C.proyecto(sys.argv[1]); os.chdir(P); B = json.load(open("bordes.json")); SR=16000; rows=[]
def f0(x):
    f,_,_=librosa.pyin(x,fmin=70,fmax=450,sr=SR,frame_length=1024); f=f[~np.isnan(f)]
    return float(np.median(f)) if len(f)>5 else None
for tid,img,acc,dlg in G.TOMAS:
    if not dlg or tid not in B or "lineas" not in B[tid] or not os.path.exists(f"clips/{tid}.mp4"): continue
    au=C.audio(f"clips/{tid}.mp4")
    for l0,l1,p,txt,_ in B[tid]["lineas"]:
        x=au[int(l0*SR):int(l1*SR)]; h=len(x)//2
        rows.append((tid,p,f0(x),f0(x[:h]),f0(x[h:]),txt[:40]))
med={c:np.median([r[2] for r in rows if r[1]==c and r[2]]) for c in {r[1] for r in rows}}
print({c:round(v) for c,v in med.items()})
for r in rows:
    d=(r[2]/med[r[1]]-1)*100 if r[2] else 0
    m=abs(r[3]/r[4]-1)*100 if r[3] and r[4] else 0
    print(f"{r[0]:4} {r[1]} f0={r[2] or 0:5.0f} ({d:+4.0f}%) mitades {m:3.0f}%  {r[5]}")
