"""Ejemplo de guion de mini novela (formato que leen los scripts). Es el arranque de «El vestido rojo» (Pilates en la Pared, AR).
Copiá este archivo como <proyecto>/guion.py y reemplazá todo con tu historia.

REGLAS DEL FORMATO
- Cada toma: (id, arranque, acción, [(personaje, emoción, "línea"), ...])
  · id: la LETRA es la escena (A1, A2, B1...). Todas las tomas de una escena empiezan con la misma letra.
  · arranque: la letra de la escena (= usa img/escenas/<letra>.png) o "prev" (= último cuadro de la toma anterior).
  · acción: qué HACEN los personajes mientras hablan, en inglés (Veo entiende mejor). Nunca caras quietas.
  · diálogo: 0 a 3 líneas. Lista vacía = toma muda. Intercambios rápidos de líneas cortas → una línea por toma.
- VOZ[clave] = ("F" o "M", "descripción de la voz en inglés"). La misma descripción en TODAS las tomas = la voz no cambia.
- POS[letra][clave] = cómo reconocer a ese personaje EN ESA ESCENA (lugar y ropa). Es lo que evita que Veo cruce las voces.
- Las líneas van escritas como se dicen, en el acento del país (acá voseo rioplatense). Números en letras si se leen raro.
"""

# Acento y estilo (van dentro de cada prompt de video)
ACENTO = ("Rioplatense Spanish from Buenos Aires with voseo (say 'acá' never 'aquí', 'vos' never 'tú', 'tenés' never 'tienes') "
          "and natural Argentine porteño intonation")
ESTILO = "Realistic candid smartphone footage"

# Personajes: retrato nuevo = texto; misma persona cambiada = (base, qué cambia)
PERSONAJES = {
    "monica_antes": "An Argentine woman aged 52, hairdresser, chestnut hair with blonde highlights, overweight with a prominent belly, slightly hunched posture, tired face, wearing a black hairdresser smock over a grey t-shirt and dark leggings.",
    "monica_despues": ("monica_antes", "now noticeably slimmer with a flat belly and an upright confident posture, radiant face, wearing a fitted red cocktail dress"),
    "agus": "An Argentine woman aged 26, slim, long straight black hair, kind face, wearing a white wedding dress with a long veil.",
    "chela": "An Argentine woman aged 65, plump, short dyed auburn hair, big gold earrings, wearing a bright floral dress, holding a champagne glass.",
}

# Escenas: primer cuadro de cada escena = composición con las referencias EN ORDEN (ref 1, ref 2...)
ESCENAS = {
    "A": ("Night, an Argentine party hall with warm string lights and round tables. On the left the slim woman in the red dress (ref 1) walks in; "
          "in the middle the bride (ref 2) turns toward her; on the right the plump aunt with the glass (ref 3) stares, mouth open.",
          ["monica_despues", "agus", "chela"]),
    "B": ("Afternoon, a small fitting room in an Argentine dress shop with a curtain and a big mirror. The overweight woman (ref 1) struggles to zip "
          "up a red cocktail dress, the zipper open at the back; the bride-to-be (ref 2) in casual clothes peeks through the curtain.",
          ["monica_antes", "agus"]),
}

VOZ = {
    "M": ("F", "Mónica, a 52-year-old Argentine woman with a medium-pitched, warm, slightly husky porteña voice"),
    "A": ("F", "Agus, a 26-year-old Argentine woman with a clear, sweet, emotional young voice"),
    "C": ("F", "Chela, a 65-year-old Argentine woman with a high-pitched, exaggerated, gossipy voice"),
}

POS = {
    "A": {"M": "the slim woman in the red dress", "A": "the bride in the white dress", "C": "the plump older woman in the floral dress"},
    "B": {"M": "the woman in the red dress inside the fitting room", "A": "the young woman peeking through the curtain"},
}

TOMAS = [
    # A · HOY · fiesta (hook)
    ("A1", "A", "The plump older woman with the glass sees the woman in the red dress walk in and freezes, mouth open.",
     [("C", "incredulous", "¿Esa es Mónica? ¡No, no puede ser!")]),
    ("A2", "prev", "The bride hugs the woman in the red dress, moved.",
     [("A", "moved", "Mamá, estás hermosa.")]),
    ("A3", "prev", "The woman in the red dress fixes her daughter's veil, smiling with teary eyes.",
     [("M", "moved", "Hace seis meses no me entraba ni una pierna en este vestido.")]),
    ("A4", "A", "The plump older woman rushes over and grabs the arm of the woman in the red dress.",
     [("C", "gossipy, whispering", "¿Qué te hiciste, nena? ¿Te operaste?")]),
    ("A5", "prev", "The woman in the red dress laughs, looks at her and takes a sip from her glass.",
     [("M", "mischievous", "Me apoyé en una pared.")]),
    # B · ANTES · probador
    ("B1", "B", "The young woman talks from outside the curtain, excited.",
     [("A", "excited", "¿Ma? ¿Salís? ¡Quiero verte!")]),
    ("B2", "prev", "The woman pulls at the zipper that won't go up and looks at herself in the mirror, frustrated.",
     [("M", "distressed, quietly", "No me entra, Agus.")]),
    ("B3", "B", "The woman covers her belly with the dress and looks down, ashamed. No dialogue, nobody speaks.", []),
]

# Placas sobre negro ANTES de la toma indicada
PLACAS = {"B1": "6 MESES ANTES"}

# Placa final (flecha + 2 líneas)
CTA = ("Tocá en", "Más información")
