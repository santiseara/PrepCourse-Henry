"""Paso 2 · Tomas con Veo 3.1 Fast (ApiMart): 8 s, 9:16, audio nativo con el diálogo. Primer cuadro = foto de la escena
o el último cuadro de la toma anterior ("prev"). Las escenas van en paralelo; las tomas de una misma escena, en orden.
Cada MAX_CADENA tomas encadenadas vuelve a arrancar desde la foto de la escena (encadenar mucho deforma las caras).
Uso: python3 gen.py <proyecto> [ids...]   (sin ids = todas las que falten)   --dry = solo imprime los prompts
Salida: <proyecto>/clips/<id>.mp4"""
import os, sys, json, threading, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comun as C

args = [a for a in sys.argv[1:] if a != "--dry"]; DRY = "--dry" in sys.argv
P, G = C.proyecto(args[0]); want = set(args[1:])
D = f"{P}/clips"; os.makedirs(D, exist_ok=True)
MODEL = os.environ.get("VEO", "veo3.1-fast")
MAX_CADENA = int(os.environ.get("MAX_CADENA", "2"))


def cap(s): return s[0].upper() + s[1:]


def prompt(tid, acc, dlg):
    pos = G.POS.get(tid[0], {}); est = G.ESTILO
    if not dlg:
        return (f"{acc} {est}, natural movement, static camera, warm natural cinematic light. "
                "Audio: quiet natural room ambience only, no music, no voices, nobody speaks. No subtitles, no text.")
    def g(c): return "male voice" if C.genero(G, c) == "M" else "female voice"
    lines = " ".join((f'Then {pos.get(p, "the person")}' if k else cap(pos.get(p, "the person")))
                     + f' ({C.voz(G, p)}) says, {emo}: "{t}"' for k, (p, emo, t) in enumerate(dlg))
    who = list(dict.fromkeys(p for p, _, _ in dlg)); quiet = [q for q in pos if q not in who]
    if len(who) == 1:
        quien = f"Only {pos.get(who[0], 'the person')} speaks in this video, with a {g(who[0])}" + (
            f"; {' and '.join(pos[q] for q in quiet)} {'stays' if len(quiet) == 1 else 'stay'} completely silent with closed mouth, only listening and reacting. " if quiet else ". ")
    else:
        quien = ("Speaker assignment is strict and must never be swapped: "
                 + "; ".join(f"{pos.get(c, c)} speaks with a {g(c)} and moves the lips only on their own lines" for c in who)
                 + ". Only one person talks at a time, never overlapping. ")
    return (f"{acc} {lines} {quien}"
            "These are the ONLY words spoken in the whole video, exactly as written, in this order: nobody says anything before, between or after them. "
            "Leave natural pauses between lines; after the last line everyone stays silent and keeps acting with gestures and reactions. "
            f"Everyone speaks {G.ACENTO}, exactly as written, with natural intonation at a natural conversational pace, "
            "with accurate lip sync, natural facial expressions, gestures and reactions from the listener. "
            f"{est}, static camera, warm natural cinematic light. "
            "Audio: only these exact spoken lines and quiet room ambience, no music, no other words. No subtitles, no text.")


def escena(tomas):
    prev, cadena = None, 0
    for tid, img, acc, dlg in tomas:
        out = f"{D}/{tid}.mp4"; ant = prev; prev = out
        foto = f"{P}/img/escenas/{tid[0]}.png" if img == "prev" else f"{P}/img/escenas/{img}.png"
        usa_prev = img == "prev" and cadena < MAX_CADENA
        cadena = cadena + 1 if usa_prev else 0
        if os.path.exists(out) or (want and tid not in want): continue
        pr = prompt(tid, acc, dlg)
        if DRY: print(f"[{tid}] arranca de: {'último cuadro de la anterior' if usa_prev else foto}\n  {pr}\n"); continue
        if usa_prev and not os.path.exists(ant): print("SIN TOMA ANTERIOR", tid, flush=True); continue
        src = C.ultimo_cuadro(ant) if usa_prev else foto
        if not os.path.exists(src): print("FALTA LA IMAGEN", src, flush=True); continue
        body = {"model": MODEL, "prompt": pr, "duration": 8, "aspect_ratio": "9:16",
                "image_urls": [C.subir(src)], "generation_type": "frame"}
        try:
            C.video(body, out, f"{P}/costos.jsonl")
            with open(f"{P}/prompts.jsonl", "a") as f: f.write(json.dumps({"id": tid, "prompt": pr}, ensure_ascii=False) + "\n")
        except BaseException as e:
            print("FALLO", tid, str(e)[:300], flush=True)   # los bloqueos del filtro no cobran: reintentar.sh


grupos = [list(g) for _, g in itertools.groupby(G.TOMAS, key=lambda x: x[0][0])]
th = [threading.Thread(target=escena, args=(g,)) for g in grupos]
[t.start() for t in th]; [t.join() for t in th]
if not DRY: print("FIN · saldo ApiMart", C.saldo())
