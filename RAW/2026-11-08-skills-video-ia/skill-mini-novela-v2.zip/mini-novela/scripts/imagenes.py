"""Paso 1 · Imágenes: retratos de los personajes y el primer cuadro de cada escena.
- PERSONAJES[k] = "descripción"            → retrato nuevo (gpt-image-2)
- PERSONAJES[k] = ("base", "qué cambia")   → misma persona editada (antes → después, misma cara)
- ESCENAS[letra] = ("descripción de la escena", ["ref1", "ref2", ...])  → composición con las referencias en ese orden
Uso: python3 imagenes.py <proyecto> [personajes|escenas] [ids...]   (sin ids = lo que falte)
     --dry  muestra los prompts sin gastar
Salida: <proyecto>/img/personajes/<k>.png y <proyecto>/img/escenas/<letra>.png"""
import os, sys
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comun as C

args = [a for a in sys.argv[1:] if a != "--dry"]; DRY = "--dry" in sys.argv
P, G = C.proyecto(args[0]); que = args[1] if len(args) > 1 else "todo"; want = set(args[2:])
LOG = f"{P}/costos.jsonl"; IP = f"{P}/img/personajes"; IE = f"{P}/img/escenas"
os.makedirs(IP, exist_ok=True); os.makedirs(IE, exist_ok=True)
FOTO = getattr(G, "FOTO", "Full-body portrait, photorealistic, natural skin texture, candid realistic phone photo look, soft warm indoor light, plain neutral background. No text, no logos, no watermark.")
CUADRO = getattr(G, "CUADRO", "Vertical 9:16 photorealistic still frame from a candid smartphone video, wide shot with all people visible from the knees up or full body, natural realistic setting, warm realistic light. Keep the exact faces, bodies, hair and clothes of the people in the reference images (reference 1, 2, 3 in order). No text, no subtitles, no logos, no watermark.")


def editar(out, prompt, refs):
    body = {"model": "gemini-nano-banana-2.1-ext", "prompt": prompt, "image_urls": [C.subir(r) for r in refs],
            "resolution": "2K", "size": "9:16"}
    return C.imagen(body, out, LOG)


def retrato(k):
    out = f"{IP}/{k}.png"; v = G.PERSONAJES[k]
    if os.path.exists(out): return
    if isinstance(v, tuple):
        base, cambio = v; ref = f"{IP}/{base}.png"
        pr = (f"The exact same person as in the reference image: same face, same hair, same skin, same age, same clothes style. "
              f"Change only this: {cambio}. Same framing and plain background. {FOTO}")
        if DRY: print(f"[{k}] (edita {base})\n  {pr}\n"); return
        if not os.path.exists(ref): print("FALTA LA BASE", base, "→ primero generá", base); return
        editar(out, pr, [ref])
    else:
        pr = f"{v} {FOTO}"
        if DRY: print(f"[{k}]\n  {pr}\n"); return
        C.imagen({"model": "gpt-image-2", "prompt": pr, "size": "9:16", "n": 1}, out, LOG)


def escena(k):
    out = f"{IE}/{k}.png"
    if os.path.exists(out): return
    desc, refs = G.ESCENAS[k]; pr = f"{desc} {CUADRO}"
    if DRY: print(f"[escena {k}] refs={refs}\n  {pr}\n"); return
    falta = [r for r in refs if not os.path.exists(f"{IP}/{r}.png")]
    if falta: print("FALTAN RETRATOS", k, falta); return
    editar(out, pr, [f"{IP}/{r}.png" for r in refs])


def lote(fn, ks):
    with ThreadPoolExecutor(4) as ex:
        for f in [ex.submit(fn, k) for k in ks]:
            try: f.result()
            except BaseException as e: print("FALLO", str(e)[:300], flush=True)


if que in ("todo", "personajes"):
    ks = [k for k in G.PERSONAJES if not want or k in want]
    lote(retrato, [k for k in ks if not isinstance(G.PERSONAJES[k], tuple)])   # primero las bases
    lote(retrato, [k for k in ks if isinstance(G.PERSONAJES[k], tuple)])       # después los "después"
if que in ("todo", "escenas"):
    lote(escena, [k for k in G.ESCENAS if not want or k in want])
if not DRY: print("Saldo ApiMart:", C.saldo())
