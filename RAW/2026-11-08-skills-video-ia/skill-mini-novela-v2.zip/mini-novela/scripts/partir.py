"""Parte tomas del guion en UNA línea por toma (ids <id>, <id>b, <id>c...). Es el arreglo para voces cruzadas y para
intercambios rápidos de líneas cortas (Veo repite o inventa). La 1ª conserva imagen y acción; las demás encadenan ("prev")
con una acción neutra donde habla solo ese personaje. Borra los clips viejos de esas tomas (los pasa a clips/malos/).
Uso: python3 partir.py <proyecto> A3 G1 K1"""
import os, sys, re, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comun as C

P, G = C.proyecto(sys.argv[1]); ids = sys.argv[2:]; gp = f"{P}/guion.py"; s = open(gp).read()
os.makedirs(f"{P}/clips/malos", exist_ok=True)
for tid in ids:
    t = next((x for x in G.TOMAS if x[0] == tid), None)
    if not t: print("NO EXISTE", tid); continue
    _, img, acc, dlg = t; pos = G.POS.get(tid[0], {})
    if len(dlg) < 2: print("YA TIENE UNA SOLA LÍNEA", tid); continue
    m = re.search(r'\(\s*["\']' + re.escape(tid) + r'["\']\s*,', s)
    if not m: print("NO ENCUENTRO EN EL ARCHIVO", tid); continue
    i = m.start(); j = s.index("]),", i) + 3
    nuevas = []
    for k, (c, emo, txt) in enumerate(dlg):
        nid = tid if k == 0 else tid + "bcdefg"[k - 1]
        quien = pos.get(c, "the person"); quien = quien[0].upper() + quien[1:]
        a = acc if k == 0 else f"{quien} says one line, {emo}; the others listen silently with closed mouths and react."
        nuevas.append(f'("{nid}", {repr(img) if k == 0 else repr("prev")}, {repr(a)},\n  [({repr(c)}, {repr(emo)}, {repr(txt)})]),')
    s = s[:i] + "\n ".join(nuevas) + s[j:]
    clip = f"{P}/clips/{tid}.mp4"
    if os.path.exists(clip): shutil.move(clip, f"{P}/clips/malos/{tid}.mp4")
    print("PARTIDA", tid, "→", len(dlg), "tomas")
open(gp, "w").write(s)
print("Listo. Ahora: gen.py y verif.py de esas tomas.")
