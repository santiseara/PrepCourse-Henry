"""Paso 6 · Control final antes de entregar:
(1) Whisper del FINAL.mp4 entero contra el guion: lista lo que falta, sobra o cambió.
(2) Hoja de contacto con un cuadro por toma (build/hoja.jpg) para revisar a ojo caras, cuerpos (antes/después) y texto quemado por Veo.
Uso: python3 qc.py <proyecto>"""
import os, sys, difflib, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comun as C
from faster_whisper import WhisperModel

P, G = C.proyecto(sys.argv[1]); out = f"{P}/FINAL.mp4"
if not os.path.exists(out): sys.exit("Primero montar.py")
# 1) guion vs. lo que se oye
g = [w for l in G.LINEAS for x in l[3].split() for w in C.norm(x)]
segs, _ = WhisperModel(os.environ.get("WHISPER", "medium"), compute_type="int8").transcribe(
    out, language="es", temperature=0, vad_filter=True, condition_on_previous_text=False)
h = [w for s in segs for x in s.text.split() for w in C.norm(x)]
sm = difflib.SequenceMatcher(None, g, h, autojunk=False)
print(f"## Parecido guion / audio: {sm.ratio():.3f}  (apuntar a ≥ 0,97)")
for t, i0, i1, j0, j1 in sm.get_opcodes():
    if t != "equal": print(f"  {t}: guion «{' '.join(g[i0:i1])}» → oído «{' '.join(h[j0:j1])}»")
# 2) hoja de contacto: cuadro del medio de cada toma
B = f"{P}/build"; cs = []
for tid, *_ in G.TOMAS:
    clip = f"{P}/clips/{tid}.mp4"
    if not os.path.exists(clip): continue
    png = f"{B}/qc_{tid}.png"
    subprocess.run([C.FF, "-v", "error", "-y", "-ss", f"{C.dur(clip) / 2:.2f}", "-i", clip, "-frames:v", "1",
                    "-vf", f"scale=180:320,drawtext=text='{tid}':fontsize=22:fontcolor=yellow:x=6:y=6", png], check=True)
    cs.append(png)
if cs:
    cols = 10; rows = (len(cs) + cols - 1) // cols
    lst = f"{B}/qc_lista.txt"; open(lst, "w").write("".join(f"file '{p}'\n" for p in cs))
    subprocess.run([C.FF, "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-vf", f"tile={cols}x{rows}",
                    "-frames:v", "1", f"{B}/hoja.jpg"], check=True)
    print("Hoja de contacto:", f"{B}/hoja.jpg", "→ mirala: misma cara en cada personaje, antes/después claro, sin texto quemado")
print("Duración final:", round(C.dur(out), 1), "s")
