#!/bin/bash
# Reintenta gen.py hasta 5 veces para las tomas que falten (los bloqueos del filtro de Veo son al azar y no cobran),
# y después las verifica. Uso: reintentar.sh <proyecto> A3 A3b G1
DIR="$(cd "$(dirname "$0")" && pwd)"; P="$1"; shift
for i in 1 2 3 4 5; do
  falta=(); for t in "$@"; do [ -f "$P/clips/$t.mp4" ] || falta+=("$t"); done
  [ ${#falta[@]} -eq 0 ] && break
  echo "intento $i: ${falta[*]}"
  python3 "$DIR/gen.py" "$P" "${falta[@]}" 2>&1 | grep -E "OK|FALLO|SIN|FALTA" | cut -c1-120
done
python3 "$DIR/verif.py" "$P" "$@" 2>&1 | grep -E "^[A-Z][0-9]+[a-z]? |PARA REGENERAR"
