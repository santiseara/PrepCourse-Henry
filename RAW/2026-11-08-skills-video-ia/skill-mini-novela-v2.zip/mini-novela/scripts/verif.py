"""Paso 3 · Verificación de cada toma: Whisper (con tiempos por palabra) ubica dónde está el guion dentro de los 8 s y marca
palabras inventadas; la alineación forzada MMS contra el guion da los bordes finos y el tiempo de cada línea (para cortar y subtitular).
Los bordes NUNCA salen de Whisper: Whisper pone la 1ª palabra en 0,00 y arrastra sílabas sueltas.
Uso: python3 verif.py <proyecto> [ids...]  → <proyecto>/bordes.json   (MAL = regenerar esa toma)"""
import json, os, sys, re, difflib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comun as C
import torch, torchaudio
from faster_whisper import WhisperModel

P, G = C.proyecto(sys.argv[1]); want = set(sys.argv[2:])
B = torchaudio.pipelines.MMS_FA; model = B.get_model(with_star=False).eval(); DIC = B.get_dict(star=None); aligner = B.get_aligner()
WM = WhisperModel(os.environ.get("WHISPER", "medium"), compute_type="int8")
OF = f"{P}/bordes.json"; OUT = json.load(open(OF)) if os.path.exists(OF) else {}


def toks(t):
    o = []
    for w in t.split():
        for p in C.norm(w):
            p = re.sub(r"[^a-z']", "", p.replace("ñ", "n"))
            if p: o.append(p)
    return o


malas = []
for tid, img, acc, dlg in G.TOMAS:
    clip = f"{P}/clips/{tid}.mp4"
    if want and tid not in want: continue
    if not os.path.exists(clip): print(tid, "FALTA"); continue
    if not want and tid in OUT and OUT[tid].get("mtime") == os.path.getmtime(clip): continue
    au = C.audio(clip); dur = len(au) / 16000
    if not dlg:   # toma muda: no tiene que hablar nadie
        segs, _ = WM.transcribe(clip, language="es", temperature=0, vad_filter=True)
        oido = " ".join(s.text.strip() for s in segs)
        OUT[tid] = dict(a=0.0, b=round(dur - 0.05, 2), dur=round(dur, 2), lineas=[], oido=oido, ratio=1.0 if not oido else 0.0,
                        extra=[oido] if oido else [], mtime=os.path.getmtime(clip))
        print(f"{tid} {'ok ' if not oido else 'MAL'} muda «{oido}»", flush=True)
        if oido: malas.append(tid)
        json.dump(OUT, open(OF, "w"), ensure_ascii=False, indent=0); continue
    segs, _ = WM.transcribe(clip, language="es", temperature=0, word_timestamps=True, vad_filter=False)
    hw = [(w.start, w.end, t) for s in segs for w in s.words for t in toks(w.word)]
    full = " ".join(t for _, _, t in hw)
    gl = [(k, w) for k, (p, e, t) in enumerate(dlg) for w in toks(t)]
    g = [w for _, w in gl]; h = [w for _, _, w in hw]
    sm = difflib.SequenceMatcher(None, g, h, autojunk=False); bl = [b for b in sm.get_matching_blocks() if b.size]
    if not bl:
        print(tid, "MAL no se oye el guion", f"«{full}»"); malas.append(tid)
        OUT[tid] = dict(ratio=0, oido=full, mtime=os.path.getmtime(clip)); continue
    j0, j1 = bl[0].b, bl[-1].b + bl[-1].size - 1
    w0 = max(0.0, hw[j0][0] - 0.6); w1 = min(dur, hw[j1][1] + 0.6)
    extra = [" ".join(h[b1:b2]) for t, a1, a2, b1, b2 in sm.get_opcodes() if t in ("insert", "replace") and b1 >= j0 and b2 <= j1 + 1 and b2 > b1]
    x = au[int(w0 * 16000):int(w1 * 16000)]
    with torch.inference_mode():
        em, _ = model(torch.from_numpy(x)[None]); em = torch.log_softmax(em, -1)
        spans = aligner(em[0], [[DIC[c] for c in w if c in DIC] or [DIC["a"]] for w in g])
    fps = em.shape[1] / (len(x) / 16000)
    W = [(w0 + sp[0].start / fps, w0 + sp[-1].end / fps) for sp in spans]
    lineas = []
    for k in range(len(dlg)):
        idx = [i for i, (kk, _) in enumerate(gl) if kk == k]
        lineas.append((round(W[idx[0]][0], 2), round(W[idx[-1]][1], 2), dlg[k][0], dlg[k][2],
                       [(round(W[i][0], 2), round(W[i][1], 2), g[i]) for i in idx]))
    a = max(0.0, W[0][0] - 0.25); b = min(dur - 0.04, W[-1][1] + 0.35)
    r = difflib.SequenceMatcher(None, "".join(g), "".join(h[j0:j1 + 1])).ratio()
    OUT[tid] = dict(a=round(a, 2), b=round(b, 2), dur=round(dur, 2), lineas=lineas, oido=full, ratio=round(r, 3), extra=extra,
                    mtime=os.path.getmtime(clip))
    mal = r < 0.9 or bool(extra)
    if mal: malas.append(tid)
    print(f"{tid} {'MAL' if mal else 'ok '} r={r:.2f} [{a:.2f}-{b:.2f}/{dur:.2f}] «{full}»" + (f" EXTRA={extra}" if extra else ""), flush=True)
    json.dump(OUT, open(OF, "w"), ensure_ascii=False, indent=0)
json.dump(OUT, open(OF, "w"), ensure_ascii=False, indent=0)
print("\nPARA REGENERAR:", " ".join(malas) if malas else "ninguna")
