"""Paso 4 · Rayo X de voces: detecta cuando Veo le da la línea al personaje equivocado (voces cruzadas) o mezcla dos voces.
Por cada línea (tiempos de bordes.json) mide la huella de voz ECAPA contra el promedio de su personaje y de los demás, y el tono F0.
Marcas: GENERO (tono de hombre en una mujer o al revés), CRUCE (suena más a otro personaje), MEZCLA (dos voces en la misma línea),
PISADA (arranca sin aire encima del otro), RAPIDO (> 8,5 sílabas/s).
Ojo: un hombre riendo o gritando puede dar F0 alto; si la marca es solo GENERO y CRUCE no aparece, escuchala antes de regenerar.
Uso: python3 voces.py <proyecto>   (necesita: pip install speechbrain librosa)"""
import os, sys, json, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comun as C
import numpy as np, librosa
librosa.pyin(np.zeros(4096, np.float32), fmin=70, fmax=450, sr=16000)   # librosa ANTES que speechbrain (choque de imports)
import torch
from speechbrain.inference.speaker import EncoderClassifier

SR = 16000
P, G = C.proyecto(sys.argv[1]); BOR = json.load(open(f"{P}/bordes.json"))
enc = EncoderClassifier.from_hparams(source="speechbrain/spkrec-ecapa-voxceleb", savedir=os.path.expanduser("~/.cache/speechbrain_ecapa"),
                                     run_opts={"device": "cpu"})


def emb(x):
    with torch.no_grad(): e = enc.encode_batch(torch.from_numpy(x)[None]).squeeze().numpy()
    return e / np.linalg.norm(e)


def f0(x):
    f, _, _ = librosa.pyin(x, fmin=70, fmax=450, sr=SR, frame_length=1024); f = f[~np.isnan(f)]
    return float(np.median(f)) if len(f) > 5 else None


def sil(t): return len(re.findall(r"[aeiouáéíóúü]+", t.lower()))


rows = []
for tid, img, acc, dlg in G.TOMAS:
    if not dlg or tid not in BOR or "lineas" not in BOR[tid]: continue
    clip = f"{P}/clips/{tid}.mp4"
    if not os.path.exists(clip) or BOR[tid].get("mtime") != os.path.getmtime(clip):
        print("  (salteo", tid, "→ falta el clip o no está verificado: correr verif.py)"); continue
    au = C.audio(clip); lin = BOR[tid]["lineas"]
    for k, (l0, l1, p, txt, _) in enumerate(lin):
        x = au[int(l0 * SR):int(l1 * SR)]; d = l1 - l0
        r = dict(toma=tid, p=p, txt=txt, dur=round(d, 2), sps=round(sil(txt) / max(d, 0.1), 1))
        if k: r["gap"] = round(l0 - lin[k - 1][1], 2); r["p_ant"] = lin[k - 1][2]
        if d >= 0.7 and len(x) >= int(0.5 * SR):
            r["e"] = emb(x); r["f0"] = f0(x)
            if d >= 2.0: h = len(x) // 2; r["mitades"] = float(np.dot(emb(x[:h]), emb(x[h:])))
        rows.append(r)
CEN = {}
for c in sorted({r["p"] for r in rows}):
    E = np.array([r["e"] for r in rows if r["p"] == c and "e" in r])
    if not len(E): continue
    m = E.mean(0); m /= np.linalg.norm(m); s = E @ m
    keep = E[s >= np.percentile(s, 30)] if len(E) >= 5 else E   # una voz equivocada no ensucia el promedio
    m = keep.mean(0); CEN[c] = m / np.linalg.norm(m)
marcadas = []
for r in rows:
    f = []
    if r.get("f0"):
        if C.genero(G, r["p"]) == "M" and r["f0"] > 175: f.append(f"GENERO f0={r['f0']:.0f} (debería ser hombre)")
        if C.genero(G, r["p"]) == "F" and r["f0"] < 150: f.append(f"GENERO f0={r['f0']:.0f} (debería ser mujer)")
    if "e" in r and len(CEN) > 1:
        propio = float(r["e"] @ CEN[r["p"]]); otros = {c: float(r["e"] @ CEN[c]) for c in CEN if c != r["p"]}
        c2 = max(otros, key=otros.get)
        if otros[c2] > propio + 0.05: f.append(f"CRUCE suena a {c2} ({otros[c2]:.2f} vs {propio:.2f})")
    if r.get("mitades") is not None and r["mitades"] < 0.45: f.append(f"MEZCLA ({r['mitades']:.2f})")
    if r.get("gap") is not None and r["p_ant"] != r["p"] and r["gap"] < 0.08: f.append(f"PISADA gap={r['gap']:.2f}")
    if r["sps"] > 8.5: f.append(f"RAPIDO {r['sps']} síl/s")
    if f:
        print(f"  {r['toma']:5} {r['p']} «{r['txt'][:60]}»  " + " | ".join(f)); marcadas.append(r["toma"])
marcadas = list(dict.fromkeys(marcadas))
print("\nTOMAS CON VOZ SOSPECHOSA:", " ".join(marcadas) if marcadas else "ninguna")
print("Arreglo: partir.py (una línea por toma) y regenerar esas tomas.")
